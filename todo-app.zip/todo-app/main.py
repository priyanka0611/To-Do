from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, constr

app = FastAPI(title="Todo App")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Lazy-load speller to avoid slow startup
_speller = None

def get_speller():
    global _speller
    if _speller is None:
        from autocorrect import Speller
        _speller = Speller(lang="en")
    return _speller


class AutocorrectRequest(BaseModel):
    text: constr(max_length=5000)


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request=request, name="index.html")


@app.post("/api/autocorrect")
async def autocorrect(body: AutocorrectRequest):
    spell = get_speller()
    corrected = spell(body.text)
    return {"corrected": corrected}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
