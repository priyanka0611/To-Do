/* =============================================================
   STATE.JS — Application State Variables, Constants,
   and DOM Element References
   ============================================================= */

// ===== Storage Keys =====
const STORAGE_KEY  = "todo_app_data";
const THEME_KEY    = "todo_app_theme";
const SYSTEMS_KEY  = "todo_app_systems";
const NOTIFIED_KEY = "todo_app_notified";

// ===== Application State =====
let data = { lists: [], activeListId: null };
let systems = [];          // Array of { id, name, freq, checkins: ["2026-04-15", ...], created }
let editingId = null;      // ID of task currently being edited
let deletingId = null;     // ID of task pending deletion
let deletingListId = null; // ID of list pending deletion
let renamingListId = null; // ID of list being renamed
let deletingSystemId = null; // ID of system pending deletion
let initialTaskIds = new Set(); // Track initial task IDs for "New" badge
let currentMode = "today"; // Current view: today | tasks | focus | insights | systems

// ===== Focus Mode State =====
let focusInterval = null;     // setInterval handle for focus timer
let focusRemaining = 25 * 60; // Seconds remaining in focus session
let focusPaused = false;      // Whether focus timer is paused
let focusTaskId = null;       // ID of task being focused on

// ===== DOM Shorthand Selectors =====
const $  = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

// ===== DOM References — Tabs & Task List =====
const tabsScroll     = $("#tabsScroll");
const addListBtn     = $("#addListBtn");
const taskList       = $("#taskList");
const emptyState     = $("#emptyState");
const emptyText      = $("#emptyText");

// ===== DOM References — Add/Edit Form =====
const formTitle      = $("#formTitle");
const titleInput     = $("#taskTitle");
const dueInput       = $("#taskDue");
const timeInput      = $("#taskTime");
const priorityInput  = $("#taskPriority");
const categoryInput  = $("#taskCategory");
const saveBtn        = $("#saveBtn");
const cancelBtn      = $("#cancelBtn");

// ===== DOM References — Filters =====
const searchInput    = $("#searchInput");
const filterStatus   = $("#filterStatus");
const filterPriority = $("#filterPriority");
const filterCategory = $("#filterCategory");
const sortBy         = $("#sortBy");

// ===== DOM References — Modals =====
const deleteModal       = $("#deleteModal");
const confirmDelete     = $("#confirmDelete");
const cancelDelete      = $("#cancelDelete");
const renameModal       = $("#renameModal");
const renameInput       = $("#renameInput");
const confirmRename     = $("#confirmRename");
const cancelRename      = $("#cancelRename");
const deleteListModal   = $("#deleteListModal");
const confirmDeleteList = $("#confirmDeleteList");
const cancelDeleteList  = $("#cancelDeleteList");
const deleteSystemModal    = $("#deleteSystemModal");
const confirmDeleteSystem  = $("#confirmDeleteSystem");
const cancelDeleteSystem   = $("#cancelDeleteSystem");

// ===== DOM References — Theme & Notifications =====
const themeToggle    = $("#themeToggle");
const categorySugg   = $("#categorySuggestions");

// ===== DOM References — Brain Dump (Tasks View) =====
const dumpToggle     = $("#dumpToggle");
const dumpBody       = $("#dumpBody");
const dumpText       = $("#dumpText");
const parseDumpBtn   = $("#parseDumpBtn");
const autocorrectBtn = $("#autocorrectBtn");
const dumpStatus     = $("#dumpStatus");
const dumpPreview    = $("#dumpPreview");
const dumpList       = $("#dumpList");
const dumpSelectAll  = $("#dumpSelectAll");
const addDumpTasksBtn= $("#addDumpTasksBtn");

// ===== DOM References — Views =====
const systemsView  = $("#systemsView");
const todayView    = $("#todayView");
const focusViewEl  = $("#focusView");
const insightsView = $("#insightsView");
const tasksViewEls = { tabs: $(".tabs-bar"), layout: $(".main-layout") };

// ===== DOM References — Systems =====
const sysList      = $("#sysList");
const sysEmptyState = $("#sysEmptyState");
const sysNameInput = $("#sysName");
const sysTimeInput = $("#sysTime");
const sysFreqInput = $("#sysFreq");
const addSystemBtn = $("#addSystemBtn");

// ===== DOM References — Mode Toggle =====
const modeBtns = $$(".mode-btn");

// ===== DOM References — Stats =====
const totalCount   = $("#totalCount");
const pendingCount = $("#pendingCount");
const doneCount    = $("#doneCount");
const overdueCount = $("#overdueCount");
