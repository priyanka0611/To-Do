/* =============================================================
   HELPERS.JS — Utility Functions: ID Generation, HTML Escaping,
   Date/Time Formatting, Priority Weights, List Helpers
   ============================================================= */

/**
 * Generate a unique ID using timestamp + random string.
 * @returns {string} A short unique identifier
 */
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/**
 * Escape HTML special characters to prevent XSS.
 * @param {string} str - Raw string to escape
 * @returns {string} HTML-safe string
 */
function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

/**
 * Format a date string (YYYY-MM-DD) into a readable format.
 * @param {string} dateStr - ISO date string
 * @returns {string} Formatted date like "Jun 15, 2025"
 */
function formatDate(dateStr) {
  if (!dateStr) return "";
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

/**
 * Format a time string (HH:MM) into 12-hour format.
 * @param {string} timeStr - 24-hour time string
 * @returns {string} Formatted time like "2:30 PM"
 */
function formatTime(timeStr) {
  if (!timeStr) return "";
  const [h, m] = timeStr.split(":").map(Number);
  const ampm = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 || 12;
  return `${h12}:${m.toString().padStart(2, '0')} ${ampm}`;
}

/**
 * Check if a task is overdue (past due date and not completed).
 * @param {Object} task - Task object with due and done properties
 * @returns {boolean} True if the task is overdue
 */
function isOverdue(task) {
  if (!task.due || task.done) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return new Date(task.due + "T00:00:00") < today;
}

/** Priority weight mapping for sorting tasks */
const PRIORITY_WEIGHT = { high: 3, medium: 2, low: 1 };

/**
 * Get the currently active list from the data store.
 * @returns {Object|null} The active list object or null
 */
function getActiveList() {
  return data.lists.find((l) => l.id === data.activeListId) || data.lists[0] || null;
}

/**
 * Get tasks from the currently active list.
 * @returns {Array} Array of task objects
 */
function getTasks() {
  const list = getActiveList();
  return list ? list.tasks : [];
}

/**
 * Pick a random element from an array.
 * @param {Array} arr - Array to choose from
 * @returns {*} A random element
 */
function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

/**
 * Get today's date as YYYY-MM-DD string.
 * Used by systems engine and notifications.
 * @returns {string} Today's date in ISO format
 */
function todayStr() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
}

/**
 * Get today's date as YYYY-MM-DD string (alias for todayStr).
 * Used by notifications and top3 rendering.
 * @returns {string} Today's date in ISO format
 */
function todayStr2() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
}

/**
 * Get current time as HH:MM string.
 * Used by notification reminder checks.
 * @returns {string} Current time in 24-hour format
 */
function currentHHMM() {
  const d = new Date();
  return String(d.getHours()).padStart(2,"0") + ":" + String(d.getMinutes()).padStart(2,"0");
}
