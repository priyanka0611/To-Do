/* =============================================================
   TODAY.JS — Today Landing Page: Greeting, Motivational Messages,
   Top 3 Priority Tasks, Today Brain Dump Handler
   ============================================================= */

/**
 * Get a time-of-day greeting with emoji.
 * @returns {string} Greeting like "Good morning ☀️"
 */
function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning ☀️";
  if (h < 17) return "Good afternoon 👋";
  return "Good evening 🌙";
}

/**
 * Render the Today view: greeting, date, motivation, and top 3 tasks.
 */
function renderTodayView() {
  // Greeting
  const greetEl = document.getElementById("todayGreeting");
  const dateEl = document.getElementById("todayDate");
  if (greetEl) greetEl.textContent = getGreeting();
  if (dateEl) {
    dateEl.textContent = new Date().toLocaleDateString("en-US", {
      weekday: "long", month: "long", day: "numeric", year: "numeric"
    });
  }

  // Top 3 priorities
  renderTop3();

  // Motivational message
  const motEl = document.getElementById("todayMotivation");
  if (motEl) {
    let allTasks = [];
    data.lists.forEach((l) => allTasks.push(...l.tasks));
    const pending = allTasks.filter((t) => !t.done).length;
    const done = allTasks.filter((t) => t.done).length;
    const overdue = allTasks.filter((t) => isOverdue(t)).length;
    motEl.textContent = getMotivation(pending, done, overdue);
  }
}

/**
 * Generate a context-aware motivational message based on task status.
 * @param {number} pending - Number of pending tasks
 * @param {number} done - Number of completed tasks
 * @param {number} overdue - Number of overdue tasks
 * @returns {string} A motivational message with emoji
 */
function getMotivation(pending, done, overdue) {
  if (done > 0 && pending === 0) {
    return pickRandom([
      "All done! You crushed it today 🎉",
      "Nothing left — go enjoy your day ✨",
      "Clean slate. You earned some rest 💆",
    ]);
  }
  if (done >= 5) {
    return pickRandom([
      `${done} tasks done — you're on fire today 🔥`,
      "Look at you go! Incredible momentum 💪",
      "You're making serious progress today ⚡",
    ]);
  }
  if (done >= 3) {
    return pickRandom([
      "You're doing great — keep the flow going 🌊",
      "3+ tasks done. That's a solid day already 👏",
      "Nice rhythm! One task at a time 🎯",
    ]);
  }
  if (overdue > 0 && pending > 0) {
    return pickRandom([
      "A few things slipped — that's okay, start here 💛",
      "Yesterday's tasks? Today's fresh start 🌅",
      "Overdue doesn't mean over. You've got this 🤝",
    ]);
  }
  if (pending <= 3 && pending > 0) {
    return pickRandom([
      `Just ${pending} task${pending > 1 ? 's' : ''} — totally doable 😊`,
      "3 tasks is enough for a great day ✌️",
      "Small list, big impact. Quality over quantity 🌟",
    ]);
  }
  if (pending > 3) {
    return pickRandom([
      "Focus on the top 3 — the rest can wait 🧘",
      "Progress > perfection. One step at a time 🚶",
      "You don't have to do it all today. Just start 💙",
      "Pick one task. Finish it. Repeat. 🔁",
    ]);
  }
  // No tasks at all
  return pickRandom([
    "A blank canvas. What will you create today? 🎨",
    "No tasks yet — take a moment to plan your day 📝",
    "Ready when you are. Add your first task 🚀",
  ]);
}

/**
 * Score and rank all pending tasks to find the top 3 priorities.
 * Scoring factors: overdue status, due date proximity, priority level, time set.
 * @returns {Array<{task: Object, score: number}>} Top 3 scored tasks
 */
function getTop3Tasks() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayMs = today.getTime();

  // Gather all pending tasks across all lists
  const pending = [];
  data.lists.forEach((list) => {
    list.tasks.forEach((task) => {
      if (!task.done) pending.push(task);
    });
  });

  // Score each task
  const scored = pending.map((task) => {
    let score = 0;

    // Overdue = highest urgency
    if (task.due) {
      const dueDate = new Date(task.due + "T00:00:00");
      const diffDays = Math.round((dueDate - todayMs) / 86400000);
      if (diffDays < 0) {
        score += 100 + Math.min(Math.abs(diffDays), 30);
      } else if (diffDays === 0) {
        score += 80; // due today
      } else if (diffDays === 1) {
        score += 60; // due tomorrow
      } else if (diffDays <= 3) {
        score += 40; // due within 3 days
      } else if (diffDays <= 7) {
        score += 20; // due this week
      }
    }

    // Priority boost
    const pw = { high: 30, medium: 15, low: 5 };
    score += pw[task.priority] || 0;

    // Time-based boost (tasks with a time set today)
    if (task.time && (!task.due || task.due === todayStr2())) {
      score += 10;
    }

    return { task, score };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, 3);
}

/**
 * Render the Top 3 priority tasks in the Today view.
 * Shows rank badges, due date info, and priority labels.
 */
function renderTop3() {
  const section = document.getElementById("top3Section");
  const list = document.getElementById("top3List");
  if (!section || !list) return;

  const top3 = getTop3Tasks();
  if (top3.length === 0) {
    list.innerHTML = `<div class="top3-empty">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="28" height="28" style="color:var(--text3);margin-bottom:4px"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="10"/></svg>
      <span>No priorities set for today</span>
    </div>`;
    return;
  }

  const today = todayStr2();

  list.innerHTML = top3.map((item, i) => {
    const t = item.task;
    const rank = i + 1;
    let metaParts = [];
    if (t.due) {
      const dueDate = new Date(t.due + "T00:00:00");
      const todayDate = new Date(today + "T00:00:00");
      const diff = Math.round((dueDate - todayDate) / 86400000);
      if (diff < 0) metaParts.push(`<span class="top3-overdue">Overdue ${Math.abs(diff)}d</span>`);
      else if (diff === 0) metaParts.push("Due today");
      else if (diff === 1) metaParts.push("Due tomorrow");
      else metaParts.push("Due " + formatDate(t.due));
    }
    if (t.time) metaParts.push(formatTime(t.time));
    if (t.category) metaParts.push(escapeHtml(t.category));

    return `<div class="top3-item">
      <div class="top3-rank r${rank}">${rank}</div>
      <div class="top3-info">
        <div class="top3-title">${escapeHtml(t.title)}</div>
        <div class="top3-meta">
          <span class="top3-badge bp-${t.priority}">${t.priority}</span>
          ${metaParts.join(" · ")}
        </div>
      </div>
    </div>`;
  }).join("");
}

// ===== Today Brain Dump Handler =====

/**
 * Handle "Add as Tasks" button in the Today view brain dump.
 * Parses text, creates tasks, and shows confirmation.
 */
document.getElementById("todayDumpBtn").addEventListener("click", () => {
  const textarea = document.getElementById("todayDumpText");
  const statusEl = document.getElementById("todayDumpStatus");
  const text = textarea.value.trim();
  if (!text) { textarea.focus(); return; }

  const parsed = parseDumpText(text);
  if (parsed.length === 0) {
    statusEl.textContent = "Couldn't find any tasks — try rephrasing";
    statusEl.style.color = "var(--red)";
    setTimeout(() => { statusEl.textContent = ""; }, 3000);
    return;
  }

  const list = getActiveList();
  if (!list) return;

  parsed.forEach((title) => {
    list.tasks.push({
      id: generateId(),
      title: title,
      due: null,
      time: null,
      priority: "medium",
      category: null,
      done: false,
      created: Date.now(),
    });
  });

  save();
  renderAll();
  renderTodayView();

  textarea.value = "";
  statusEl.style.color = "var(--green)";
  statusEl.textContent = `✓ ${parsed.length} task${parsed.length > 1 ? "s" : ""} added!`;
  setTimeout(() => { statusEl.textContent = ""; }, 3000);
});
