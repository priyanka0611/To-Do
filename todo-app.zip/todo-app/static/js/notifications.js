/* =============================================================
   NOTIFICATIONS.JS — Browser Notification System: Permission
   Handling, Reminder Checks, Notification Bell Status
   ============================================================= */

/**
 * Load the set of already-notified IDs for today from localStorage.
 * Resets if the stored day doesn't match today.
 * @returns {Object} { day: string, ids: Set }
 */
function loadNotified() {
  try {
    const raw = JSON.parse(localStorage.getItem(NOTIFIED_KEY));
    if (raw && raw.day === todayStr2()) {
      return { day: raw.day, ids: new Set(raw.ids) };
    }
  } catch {}
  return { day: todayStr2(), ids: new Set() };
}

/**
 * Save the notified IDs set to localStorage and cloud.
 */
function saveNotified() {
  localStorage.setItem(NOTIFIED_KEY, JSON.stringify({
    day: notifState.day,
    ids: [...notifState.ids],
  }));
  saveToCloud("notified", { day: notifState.day, ids: [...notifState.ids] });
}

/**
 * Remove a task from the notified set (e.g., when task is edited).
 * @param {string} taskId - The task ID to clear from notifications
 */
function clearNotifiedFor(taskId) {
  notifState.ids.delete("task:" + taskId);
  saveNotified();
}

/** Current notification state for today */
let notifState = loadNotified();

/**
 * Request browser notification permission if not yet decided.
 */
function requestNotifPermission() {
  if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission().then(updateNotifDot);
  }
}

/**
 * Update the notification bell dot color based on permission status.
 * Green = granted, Red = denied, Gray = default.
 */
function updateNotifDot() {
  const dot = document.getElementById("notifDot");
  if (!dot || !("Notification" in window)) return;
  if (Notification.permission === "granted") {
    dot.className = "notif-dot active";
    document.getElementById("notifToggle").title = "Reminders enabled";
  } else if (Notification.permission === "denied") {
    dot.className = "notif-dot denied";
    document.getElementById("notifToggle").title = "Reminders blocked — enable in browser settings";
  } else {
    dot.className = "notif-dot";
    document.getElementById("notifToggle").title = "Click to enable reminders";
  }
}

/**
 * Send a browser notification with the given title and body.
 * @param {string} title - Notification title
 * @param {string} body - Notification body text
 * @param {string} tag - Unique tag to prevent duplicate notifications
 */
function sendNotification(title, body, tag) {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  const n = new Notification(title, {
    body: body,
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>✅</text></svg>",
    tag: tag,
    requireInteraction: true,
  });
  n.onclick = () => { window.focus(); n.close(); };
}

/**
 * Check all tasks and systems for due reminders.
 * Fires notifications for items that are due now or have passed.
 * Runs every 30 seconds via setInterval.
 */
function checkReminders() {
  // Reset tracked set at midnight
  const day = todayStr2();
  if (day !== notifState.day) {
    notifState = { day: day, ids: new Set() };
    saveNotified();
  }

  const now = currentHHMM();

  // Check tasks with time reminders
  data.lists.forEach((list) => {
    list.tasks.forEach((task) => {
      if (task.done || !task.time) return;
      if (task.due && task.due !== day) return;
      const key = "task:" + task.id;
      if (notifState.ids.has(key)) return;
      if (task.time <= now) {
        notifState.ids.add(key);
        saveNotified();
        sendNotification(
          "⏰ Task Reminder",
          task.title + (task.due ? " — Due " + formatDate(task.due) : ""),
          key
        );
      }
    });
  });

  // Check systems with scheduled times
  systems.forEach((sys) => {
    if (!sys.time) return;
    const key = "sys:" + sys.id;
    if (notifState.ids.has(key)) return;
    if (sys.checkins && sys.checkins.includes(day)) return;
    if (sys.time <= now) {
      notifState.ids.add(key);
      saveNotified();
      sendNotification(
        "🔁 System Reminder",
        sys.name + " — Time to check in!",
        key
      );
    }
  });
}

// ===== Notification Bell Click Handler =====
document.getElementById("notifToggle").addEventListener("click", () => {
  if (!("Notification" in window)) {
    alert("Your browser does not support notifications.");
    return;
  }
  if (Notification.permission === "default") {
    Notification.requestPermission().then(updateNotifDot);
  } else if (Notification.permission === "denied") {
    alert("Notifications are blocked.\n\nTo fix:\n1. Click the lock/info icon in the address bar\n2. Find 'Notifications' and set to 'Allow'\n3. Refresh the page");
  } else {
    sendNotification(
      "✅ Reminders Working!",
      "You'll get notified when a task or system is due.",
      "test-notif"
    );
  }
});
