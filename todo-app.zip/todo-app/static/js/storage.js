/* =============================================================
   STORAGE.JS — Data Persistence: LocalStorage Load/Save,
   Cloud Sync with Firebase (Debounced)
   ============================================================= */

// ===== Local Storage =====

/**
 * Load task data from localStorage.
 * Handles migration from old single-list format.
 * Populates initialTaskIds for "New" badge tracking.
 */
function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (raw && raw.lists) {
      data = raw;
    } else {
      // Migrate old single-list data format
      let oldTasks = [];
      try { oldTasks = JSON.parse(localStorage.getItem("todo_app_tasks")) || []; } catch {}
      const defaultList = { id: generateId(), name: "General", tasks: oldTasks };
      data = { lists: [defaultList], activeListId: defaultList.id };
    }
  } catch {
    const defaultList = { id: generateId(), name: "General", tasks: [] };
    data = { lists: [defaultList], activeListId: defaultList.id };
  }
  if (!data.activeListId && data.lists.length > 0) {
    data.activeListId = data.lists[0].id;
  }
  initialTaskIds = new Set();
  data.lists.forEach((l) => l.tasks.forEach((t) => initialTaskIds.add(t.id)));
}

/**
 * Save task data to localStorage and sync to cloud.
 */
function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  saveToCloud("tasks", data);
}

/**
 * Load systems/habits data from localStorage.
 */
function loadSystems() {
  try { systems = JSON.parse(localStorage.getItem(SYSTEMS_KEY)) || []; } catch { systems = []; }
}

/**
 * Save systems/habits data to localStorage and sync to cloud.
 */
function saveSystems() {
  localStorage.setItem(SYSTEMS_KEY, JSON.stringify(systems));
  saveToCloud("systems", systems);
}

// ===== Cloud Sync =====

/** Debounce timers for cloud saves, keyed by document name */
let cloudSaveTimers = {};

/**
 * Save data to Firebase Firestore with 1-second debounce.
 * Silently skips if Firebase is not configured.
 * @param {string} docName - Firestore document name ("tasks", "systems", "notified")
 * @param {*} payload - Data to save
 */
function saveToCloud(docName, payload) {
  if (typeof firebaseUid === "undefined" || !firebaseUid || typeof db === "undefined") return;

  clearTimeout(cloudSaveTimers[docName]);
  cloudSaveTimers[docName] = setTimeout(() => {
    db.collection("users").doc(firebaseUid).collection("data").doc(docName)
      .set({ value: JSON.stringify(payload), updated: Date.now() })
      .catch((err) => console.warn("Cloud save failed:", err.message));
  }, 1000);
}

/**
 * Sync data from Firebase Firestore on sign-in.
 * Downloads tasks and systems if local storage is empty.
 * Pushes local data to cloud if no cloud data exists.
 */
function syncFromCloud() {
  if (!firebaseUid || typeof db === "undefined") return;

  const userRef = db.collection("users").doc(firebaseUid).collection("data");

  // Sync tasks
  userRef.doc("tasks").get().then((doc) => {
    if (doc.exists) {
      try {
        const cloudData = JSON.parse(doc.data().value);
        if (cloudData && cloudData.lists) {
          const localTasks = data.lists.reduce((n, l) => n + l.tasks.length, 0);
          if (localTasks === 0 || !localStorage.getItem(STORAGE_KEY)) {
            data = cloudData;
            if (!data.activeListId && data.lists.length > 0) {
              data.activeListId = data.lists[0].id;
            }
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
            initialTaskIds = new Set();
            data.lists.forEach((l) => l.tasks.forEach((t) => initialTaskIds.add(t.id)));
            renderAll();
          }
        }
      } catch {}
    } else {
      saveToCloud("tasks", data);
    }
  }).catch((err) => console.warn("Cloud tasks load failed:", err.message));

  // Sync systems
  userRef.doc("systems").get().then((doc) => {
    if (doc.exists) {
      try {
        const cloudSystems = JSON.parse(doc.data().value);
        if (Array.isArray(cloudSystems)) {
          const localEmpty = systems.length === 0;
          if (localEmpty || !localStorage.getItem(SYSTEMS_KEY)) {
            systems = cloudSystems;
            localStorage.setItem(SYSTEMS_KEY, JSON.stringify(systems));
            if (currentMode === "systems") renderSystems();
          }
        }
      } catch {}
    } else {
      saveToCloud("systems", systems);
    }
  }).catch((err) => console.warn("Cloud systems load failed:", err.message));
}
