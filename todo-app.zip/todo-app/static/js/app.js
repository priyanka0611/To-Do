// ===== State =====
const STORAGE_KEY = "todo_app_data";
const THEME_KEY   = "todo_app_theme";
const SYSTEMS_KEY = "todo_app_systems";

let data = { lists: [], activeListId: null };
let systems = []; // { id, name, freq, checkins: ["2026-04-15", ...], created }
let editingId = null;
let deletingId = null;
let deletingListId = null;
let renamingListId = null;
let deletingSystemId = null;
let initialTaskIds = new Set();
let currentMode = "today";

// Focus Mode state
let focusInterval = null;
let focusRemaining = 25 * 60;
let focusPaused = false;
let focusTaskId = null;

// ===== DOM refs =====
const $  = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

const tabsScroll     = $("#tabsScroll");
const addListBtn     = $("#addListBtn");
const taskList       = $("#taskList");
const emptyState     = $("#emptyState");
const emptyText      = $("#emptyText");
const formTitle      = $("#formTitle");
const titleInput     = $("#taskTitle");
const dueInput       = $("#taskDue");
const timeInput      = $("#taskTime");
const priorityInput  = $("#taskPriority");
const categoryInput  = $("#taskCategory");
const saveBtn        = $("#saveBtn");
const cancelBtn      = $("#cancelBtn");
const searchInput    = $("#searchInput");
const filterStatus   = $("#filterStatus");
const filterPriority = $("#filterPriority");
const filterCategory = $("#filterCategory");
const sortBy         = $("#sortBy");
const deleteModal    = $("#deleteModal");
const confirmDelete  = $("#confirmDelete");
const cancelDelete   = $("#cancelDelete");
const renameModal    = $("#renameModal");
const renameInput    = $("#renameInput");
const confirmRename  = $("#confirmRename");
const cancelRename   = $("#cancelRename");
const deleteListModal = $("#deleteListModal");
const confirmDeleteList = $("#confirmDeleteList");
const cancelDeleteList  = $("#cancelDeleteList");
const themeToggle    = $("#themeToggle");
const categorySugg   = $("#categorySuggestions");

// Brain Dump DOM
const dumpToggle     = $("#dumpToggle");
const dumpBody       = $("#dumpBody");
const dumpText       = $("#dumpText");
const parseDumpBtn   = $("#parseDumpBtn");
const autocorrectBtn = $("#autocorrectBtn");
const dumpStatus     = $("#dumpStatus");
const dumpPreview    = $("#dumpPreview");
const dumpList       = $("#dumpList");
const dumpSelectAll  = $("#dumpSelectAll");
const addDumpTasksBtn= $("#addDumpTasksBtn");

// Systems DOM
const systemsView = $("#systemsView");
const todayView = $("#todayView");
const focusViewEl = $("#focusView");
const insightsView = $("#insightsView");
const tasksViewEls = { tabs: $(".tabs-bar"), layout: $(".main-layout") };
const sysList = $("#sysList");
const sysEmptyState = $("#sysEmptyState");
const sysNameInput = $("#sysName");
const sysTimeInput = $("#sysTime");
const sysFreqInput = $("#sysFreq");
const addSystemBtn = $("#addSystemBtn");
const deleteSystemModal = $("#deleteSystemModal");
const confirmDeleteSystem = $("#confirmDeleteSystem");
const cancelDeleteSystem  = $("#cancelDeleteSystem");
const modeBtns = $$(".mode-btn");

// Stats
const totalCount   = $("#totalCount");
const pendingCount = $("#pendingCount");
const doneCount    = $("#doneCount");
const overdueCount = $("#overdueCount");

// ===== Helpers =====
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function formatDate(dateStr) {
  if (!dateStr) return "";
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function formatTime(timeStr) {
  if (!timeStr) return "";
  const [h, m] = timeStr.split(":").map(Number);
  const ampm = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 || 12;
  return `${h12}:${m.toString().padStart(2, '0')} ${ampm}`;
}

function isOverdue(task) {
  if (!task.due || task.done) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return new Date(task.due + "T00:00:00") < today;
}

const PRIORITY_WEIGHT = { high: 3, medium: 2, low: 1 };

// ===== Active list helpers =====
function getActiveList() {
  return data.lists.find((l) => l.id === data.activeListId) || data.lists[0] || null;
}

function getTasks() {
  const list = getActiveList();
  return list ? list.tasks : [];
}

// ===== Persistence =====
function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (raw && raw.lists) {
      data = raw;
    } else {
      // Migrate old single-list data
      let oldTasks = [];
      try { oldTasks = JSON.parse(localStorage.getItem("todo_app_tasks")) || []; } catch {}
      const defaultList = { id: generateId(), name: "General", tasks: oldTasks };
      data = { lists: [defaultList], activeListId: defaultList.id };
    }
  } catch {
    const defaultList = { id: generateId(), name: "General", tasks: [] };
    data = { lists: [defaultList], activeListId: defaultList.id };
  }
  if (!data.activeListId && data.lists.length > 0) {
    data.activeListId = data.lists[0].id;
  }
  initialTaskIds = new Set();
  data.lists.forEach((l) => l.tasks.forEach((t) => initialTaskIds.add(t.id)));
}

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  saveToCloud("tasks", data);
}

function loadSystems() {
  try { systems = JSON.parse(localStorage.getItem(SYSTEMS_KEY)) || []; } catch { systems = []; }
}

function saveSystems() {
  localStorage.setItem(SYSTEMS_KEY, JSON.stringify(systems));
  saveToCloud("systems", systems);
}

// ===== Cloud Sync =====
let cloudSaveTimers = {};

function saveToCloud(docName, payload) {
  if (typeof firebaseUid === "undefined" || !firebaseUid || typeof db === "undefined") return;

  // Debounce: wait 1s after last change before writing
  clearTimeout(cloudSaveTimers[docName]);
  cloudSaveTimers[docName] = setTimeout(() => {
    db.collection("users").doc(firebaseUid).collection("data").doc(docName)
      .set({ value: JSON.stringify(payload), updated: Date.now() })
      .catch((err) => console.warn("Cloud save failed:", err.message));
  }, 1000);
}

function syncFromCloud() {
  if (!firebaseUid || typeof db === "undefined") return;

  const userRef = db.collection("users").doc(firebaseUid).collection("data");

  // Sync tasks
  userRef.doc("tasks").get().then((doc) => {
    if (doc.exists) {
      try {
        const cloudData = JSON.parse(doc.data().value);
        if (cloudData && cloudData.lists) {
          // Use cloud data if local is empty or cloud is newer
          const localTasks = data.lists.reduce((n, l) => n + l.tasks.length, 0);
          if (localTasks === 0 || !localStorage.getItem(STORAGE_KEY)) {
            data = cloudData;
            if (!data.activeListId && data.lists.length > 0) {
              data.activeListId = data.lists[0].id;
            }
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
            initialTaskIds = new Set();
            data.lists.forEach((l) => l.tasks.forEach((t) => initialTaskIds.add(t.id)));
            renderAll();
          }
        }
      } catch {}
    } else {
      // No cloud data yet — push local data up
      saveToCloud("tasks", data);
    }
  }).catch((err) => console.warn("Cloud tasks load failed:", err.message));

  // Sync systems
  userRef.doc("systems").get().then((doc) => {
    if (doc.exists) {
      try {
        const cloudSystems = JSON.parse(doc.data().value);
        if (Array.isArray(cloudSystems)) {
          const localEmpty = systems.length === 0;
          if (localEmpty || !localStorage.getItem(SYSTEMS_KEY)) {
            systems = cloudSystems;
            localStorage.setItem(SYSTEMS_KEY, JSON.stringify(systems));
            if (currentMode === "systems") renderSystems();
          }
        }
      } catch {}
    } else {
      saveToCloud("systems", systems);
    }
  }).catch((err) => console.warn("Cloud systems load failed:", err.message));
}

// ===== Theme =====
function initTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  document.documentElement.setAttribute("data-theme", saved || "light");
}

themeToggle.addEventListener("click", () => {
  const current = document.documentElement.getAttribute("data-theme");
  const next = current === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", next);
  localStorage.setItem(THEME_KEY, next);
});

// ===== Tabs =====
function renderTabs() {
  tabsScroll.innerHTML = "";
  data.lists.forEach((list) => {
    const tab = document.createElement("button");
    tab.className = "tab" + (list.id === data.activeListId ? " active" : "");
    const pending = list.tasks.filter((t) => !t.done).length;
    tab.innerHTML = `
      <span class="tab-name">${escapeHtml(list.name)}</span>
      <span class="tab-count">${pending}</span>
      <span class="tab-menu-btn" data-list-id="${list.id}" title="List options">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="6" r="1.5"/><circle cx="12" cy="18" r="1.5"/></svg>
      </span>
    `;
    tab.addEventListener("click", (e) => {
      if (e.target.closest(".tab-menu-btn")) return;
      data.activeListId = list.id;
      save();
      resetForm();
      renderAll();
    });
    tabsScroll.appendChild(tab);
  });
}

// Tab context menu
let openMenu = null;
function closeMenu() {
  if (openMenu) { openMenu.remove(); openMenu = null; }
  document.removeEventListener("click", closeMenu);
}

tabsScroll.addEventListener("click", (e) => {
  const menuBtn = e.target.closest(".tab-menu-btn");
  if (!menuBtn) return;
  e.stopPropagation();
  closeMenu();
  const listId = menuBtn.dataset.listId;
  const menu = document.createElement("div");
  menu.className = "tab-context-menu";
  menu.innerHTML = `
    <button data-action="rename">&#9998; Rename</button>
    <button data-action="delete" class="danger">&#128465; Delete</button>
  `;
  menuBtn.closest(".tab").appendChild(menu);
  openMenu = menu;

  menu.addEventListener("click", (ev) => {
    const action = ev.target.closest("button")?.dataset.action;
    if (action === "rename") {
      renamingListId = listId;
      const list = data.lists.find((l) => l.id === listId);
      renameInput.value = list ? list.name : "";
      renameModal.classList.add("active");
      setTimeout(() => renameInput.focus(), 50);
    } else if (action === "delete") {
      if (data.lists.length <= 1) {
        alert("You need at least one list.");
      } else {
        deletingListId = listId;
        deleteListModal.classList.add("active");
      }
    }
    closeMenu();
  });

  setTimeout(() => document.addEventListener("click", closeMenu), 0);
});

// Add new list
addListBtn.addEventListener("click", () => {
  const name = prompt("Enter list name:");
  if (!name || !name.trim()) return;
  const newList = { id: generateId(), name: name.trim(), tasks: [] };
  data.lists.push(newList);
  data.activeListId = newList.id;
  save();
  resetForm();
  renderAll();
});

// Rename modal
confirmRename.addEventListener("click", () => {
  const name = renameInput.value.trim();
  if (!name) return;
  const list = data.lists.find((l) => l.id === renamingListId);
  if (list) { list.name = name; save(); renderAll(); }
  renamingListId = null;
  renameModal.classList.remove("active");
});
cancelRename.addEventListener("click", () => {
  renamingListId = null;
  renameModal.classList.remove("active");
});
renameModal.addEventListener("click", (e) => {
  if (e.target === renameModal) { renamingListId = null; renameModal.classList.remove("active"); }
});
renameInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") confirmRename.click();
});

// Delete list modal
confirmDeleteList.addEventListener("click", () => {
  if (deletingListId && data.lists.length > 1) {
    data.lists = data.lists.filter((l) => l.id !== deletingListId);
    if (data.activeListId === deletingListId) {
      data.activeListId = data.lists[0].id;
    }
    deletingListId = null;
    save();
    resetForm();
    renderAll();
  }
  deleteListModal.classList.remove("active");
});
cancelDeleteList.addEventListener("click", () => {
  deletingListId = null;
  deleteListModal.classList.remove("active");
});
deleteListModal.addEventListener("click", (e) => {
  if (e.target === deleteListModal) { deletingListId = null; deleteListModal.classList.remove("active"); }
});

// ===== Categories =====
function getCategories() {
  const cats = new Set();
  getTasks().forEach((t) => { if (t.category) cats.add(t.category); });
  return [...cats].sort();
}

function updateCategoryUI() {
  const cats = getCategories();
  const current = filterCategory.value;
  filterCategory.innerHTML = '<option value="all">All Categories</option>';
  cats.forEach((c) => {
    const opt = document.createElement("option");
    opt.value = c;
    opt.textContent = c;
    filterCategory.appendChild(opt);
  });
  filterCategory.value = current;
  categorySugg.innerHTML = "";
  cats.forEach((c) => {
    const opt = document.createElement("option");
    opt.value = c;
    categorySugg.appendChild(opt);
  });
}

// ===== Stats =====
function updateStats() {
  const tasks = getTasks();
  const total   = tasks.length;
  const done    = tasks.filter((t) => t.done).length;
  const pending = total - done;
  const overdue = tasks.filter((t) => isOverdue(t)).length;

  totalCount.textContent   = total;
  pendingCount.textContent = pending;
  doneCount.textContent    = done;
  overdueCount.textContent = overdue;
}

// ===== Render Tasks =====
function getFilteredTasks() {
  let list = [...getTasks()];

  const q = searchInput.value.trim().toLowerCase();
  if (q) {
    list = list.filter((t) =>
      t.title.toLowerCase().includes(q) ||
      (t.category && t.category.toLowerCase().includes(q))
    );
  }

  const status = filterStatus.value;
  if (status === "pending")   list = list.filter((t) => !t.done);
  if (status === "completed") list = list.filter((t) => t.done);

  const pri = filterPriority.value;
  if (pri !== "all") list = list.filter((t) => t.priority === pri);

  const cat = filterCategory.value;
  if (cat !== "all") list = list.filter((t) => t.category === cat);

  const sort = sortBy.value;
  list.sort((a, b) => {
    switch (sort) {
      case "created-desc": return b.created - a.created;
      case "created-asc":  return a.created - b.created;
      case "due-asc":
        if (!a.due && !b.due) return 0;
        if (!a.due) return 1;
        if (!b.due) return -1;
        return a.due.localeCompare(b.due);
      case "due-desc":
        if (!a.due && !b.due) return 0;
        if (!a.due) return 1;
        if (!b.due) return -1;
        return b.due.localeCompare(a.due);
      case "priority-desc": return (PRIORITY_WEIGHT[b.priority] || 0) - (PRIORITY_WEIGHT[a.priority] || 0);
      case "priority-asc":  return (PRIORITY_WEIGHT[a.priority] || 0) - (PRIORITY_WEIGHT[b.priority] || 0);
      default: return 0;
    }
  });

  return list;
}

function renderTasks() {
  const filtered = getFilteredTasks();
  const tasks = getTasks();
  taskList.innerHTML = "";

  if (filtered.length === 0) {
    emptyState.style.display = "block";
    emptyText.textContent = tasks.length === 0
      ? "No tasks yet. Add one above!"
      : "No tasks match your filters.";
  } else {
    emptyState.style.display = "none";
  }

  filtered.forEach((task) => {
    const card = document.createElement("div");
    card.className = "task-card" + (task.done ? " completed" : "");

    // Build meta badges
    const badges = [];
    badges.push(`<span class="badge badge-priority bp-${task.priority}">${task.priority}</span>`);
    if (task.category) {
      badges.push(`<span class="badge badge-category">${escapeHtml(task.category)}</span>`);
    }
    if (!initialTaskIds.has(task.id)) {
      badges.push('<span class="badge badge-new">New</span>');
    }

    // Due date
    let dueLine = '';
    if (task.due) {
      const ov = isOverdue(task);
      const timeStr = task.time ? ' ' + formatTime(task.time) : '';
      dueLine = `<div class="task-info-item${ov ? ' overdue' : ''}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>${ov ? 'Overdue: ' : ''}${formatDate(task.due)}${timeStr}</div>`;
    } else if (task.time) {
      dueLine = `<div class="task-info-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>${formatTime(task.time)}</div>`;
    }

    card.innerHTML = `
      <div class="priority-stripe p-${task.priority}"></div>
      <div class="task-body">
        <div class="task-header">
          <div class="task-check ${task.done ? 'checked' : ''}" data-id="${task.id}" role="checkbox" aria-checked="${task.done}" tabindex="0">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 13l4 4L19 7"/></svg>
          </div>
          <div class="task-title">${escapeHtml(task.title)}</div>
        </div>
        <div class="task-info">
          ${badges.join('')}
          ${dueLine}
          ${(task.subtasks && task.subtasks.length) ? `<span class="badge badge-subtasks">${task.subtasks.filter(s=>s.done).length}/${task.subtasks.length} subtasks</span>` : ''}
        </div>
        ${(task.subtasks && task.subtasks.length) ? `
        <div class="subtask-list">
          <div class="subtask-progress"><div class="subtask-progress-fill" style="width:${Math.round((task.subtasks.filter(s=>s.done).length / task.subtasks.length)*100)}%"></div></div>
          ${task.subtasks.map(st => `
            <div class="subtask-item">
              <div class="subtask-check ${st.done ? 'checked' : ''}" data-task-id="${task.id}" data-sub-id="${st.id}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 13l4 4L19 7"/></svg>
              </div>
              <span class="${st.done ? 'subtask-done' : ''}">${escapeHtml(st.title)}</span>
            </div>
          `).join('')}
        </div>` : ''}
      </div>
      <div class="task-footer">
        <div class="task-info">${dueLine ? '' : '<span></span>'}</div>
        <div class="task-actions">
          <button class="btn-edit" data-id="${task.id}" title="Edit">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
          <button class="btn-del" data-id="${task.id}" title="Delete">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
          </button>
        </div>
      </div>
    `;
    taskList.appendChild(card);
  });

  updateStats();
  updateCategoryUI();
}

// ===== Today's Top 3 =====
function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning ☀️";
  if (h < 17) return "Good afternoon 👋";
  return "Good evening 🌙";
}

function renderTodayView() {
  // Greeting
  const greetEl = document.getElementById("todayGreeting");
  const dateEl = document.getElementById("todayDate");
  if (greetEl) greetEl.textContent = getGreeting();
  if (dateEl) {
    dateEl.textContent = new Date().toLocaleDateString("en-US", {
      weekday: "long", month: "long", day: "numeric", year: "numeric"
    });
  }

  // Top 3
  renderTop3();

  // Motivational message
  const motEl = document.getElementById("todayMotivation");
  if (motEl) {
    let allTasks = [];
    data.lists.forEach((l) => allTasks.push(...l.tasks));
    const pending = allTasks.filter((t) => !t.done).length;
    const done = allTasks.filter((t) => t.done).length;
    const overdue = allTasks.filter((t) => isOverdue(t)).length;
    motEl.textContent = getMotivation(pending, done, overdue);
  }
}

// ===== Weekly Insights =====
function renderInsights() {
  const el = document.getElementById("insightsList");
  if (!el) return;

  const allTasks = [];
  data.lists.forEach((l) => allTasks.push(...l.tasks));

  if (allTasks.length === 0) {
    el.innerHTML = '<div class="insights-empty">Add some tasks to see your insights</div>';
    return;
  }

  const now = new Date();
  const weekAgo = new Date(now);
  weekAgo.setDate(weekAgo.getDate() - 7);
  const weekAgoMs = weekAgo.getTime();

  // Tasks created this week
  const thisWeek = allTasks.filter((t) => t.created >= weekAgoMs);
  const thisWeekDone = thisWeek.filter((t) => t.done);

  // All completed tasks with completedAt
  const completedWithTime = allTasks.filter((t) => t.done && t.completedAt);
  const completedThisWeek = completedWithTime.filter((t) => t.completedAt >= weekAgoMs);

  const insights = [];

  // 1. Weekly completion rate
  if (thisWeek.length > 0) {
    const pct = Math.round((thisWeekDone.length / thisWeek.length) * 100);
    let emoji, comment;
    if (pct >= 80) { emoji = "🔥"; comment = "You're crushing it!"; }
    else if (pct >= 50) { emoji = "💪"; comment = "Solid progress this week"; }
    else if (pct >= 20) { emoji = "🌱"; comment = "Room to grow — keep going"; }
    else { emoji = "🐢"; comment = "Slow week — that's okay, refocus"; }
    const barColor = pct >= 70 ? "bar-green" : pct >= 40 ? "bar-orange" : "bar-red";
    insights.push({
      emoji,
      text: `You completed ${pct}% of this week's tasks`,
      detail: `${thisWeekDone.length} of ${thisWeek.length} tasks done. ${comment}`,
      bar: { pct, color: barColor },
    });
  }

  // 2. Most productive time
  if (completedWithTime.length >= 3) {
    const hourCounts = {};
    completedWithTime.forEach((t) => {
      const h = new Date(t.completedAt).getHours();
      hourCounts[h] = (hourCounts[h] || 0) + 1;
    });
    const peakHour = Object.entries(hourCounts).sort((a, b) => b[1] - a[1])[0];
    if (peakHour) {
      const h = parseInt(peakHour[0]);
      const ampm = h >= 12 ? "PM" : "AM";
      const h12 = h % 12 || 12;
      const period = h < 12 ? "morning" : h < 17 ? "afternoon" : "evening";
      insights.push({
        emoji: "⏰",
        text: `Most productive around ${h12} ${ampm}`,
        detail: `You tend to complete tasks in the ${period}. Try scheduling important work then.`,
      });
    }
  }

  // 3. Priority behavior
  const highPri = allTasks.filter((t) => t.priority === "high");
  const highDone = highPri.filter((t) => t.done);
  const highPending = highPri.filter((t) => !t.done);
  if (highPri.length >= 2) {
    const highPct = Math.round((highDone.length / highPri.length) * 100);
    if (highPending.length > highDone.length) {
      const overdueHigh = highPending.filter((t) => isOverdue(t));
      insights.push({
        emoji: "⚠️",
        text: `${highPending.length} high-priority task${highPending.length > 1 ? "s" : ""} still pending`,
        detail: overdueHigh.length > 0
          ? `${overdueHigh.length} of them ${overdueHigh.length > 1 ? "are" : "is"} overdue. Consider tackling these first.`
          : "Try focusing on these before lower-priority items.",
      });
    } else if (highPct >= 70) {
      insights.push({
        emoji: "🎯",
        text: `${highPct}% of high-priority tasks completed`,
        detail: "Great job focusing on what matters most!",
        bar: { pct: highPct, color: "bar-green" },
      });
    }
  }

  // 4. Streak / consistency
  const last7Days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    last7Days.push(d.toISOString().slice(0, 10));
  }
  const activeDays = new Set();
  completedWithTime.forEach((t) => {
    const ds = new Date(t.completedAt).toISOString().slice(0, 10);
    if (last7Days.includes(ds)) activeDays.add(ds);
  });
  if (completedWithTime.length >= 3) {
    const dayCount = activeDays.size;
    if (dayCount >= 5) {
      insights.push({
        emoji: "📅",
        text: `Active ${dayCount} out of 7 days this week`,
        detail: "Impressive consistency! You're building a strong habit.",
        bar: { pct: Math.round((dayCount / 7) * 100), color: "bar-blue" },
      });
    } else if (dayCount >= 3) {
      insights.push({
        emoji: "📅",
        text: `Active ${dayCount} out of 7 days this week`,
        detail: "Good start — try to stay consistent daily.",
        bar: { pct: Math.round((dayCount / 7) * 100), color: "bar-orange" },
      });
    }
  }

  // 5. Category insight
  if (completedThisWeek.length >= 3) {
    const catCounts = {};
    completedThisWeek.forEach((t) => {
      const cat = t.category || "Uncategorized";
      catCounts[cat] = (catCounts[cat] || 0) + 1;
    });
    const topCat = Object.entries(catCounts).sort((a, b) => b[1] - a[1])[0];
    if (topCat && topCat[1] >= 2) {
      insights.push({
        emoji: "📂",
        text: `"${topCat[0]}" was your top focus area`,
        detail: `${topCat[1]} tasks completed in this category this week.`,
      });
    }
  }

  // Fallback
  if (insights.length === 0) {
    el.innerHTML = '<div class="insights-empty">Complete a few more tasks to unlock insights ✨</div>';
    return;
  }

  el.innerHTML = insights.map((ins) => `
    <div class="insight-card">
      <div class="insight-emoji">${ins.emoji}</div>
      <div class="insight-body">
        <div class="insight-text">${ins.text}</div>
        <div class="insight-detail">${ins.detail}</div>
        ${ins.bar ? `<div class="insight-bar-wrap"><div class="insight-bar ${ins.bar.color}" style="width:${ins.bar.pct}%"></div></div>` : ""}
      </div>
    </div>
  `).join("");
}

function getMotivation(pending, done, overdue) {
  // Context-aware messages
  if (done > 0 && pending === 0) {
    return pickRandom([
      "All done! You crushed it today 🎉",
      "Nothing left — go enjoy your day ✨",
      "Clean slate. You earned some rest 💆",
    ]);
  }
  if (done >= 5) {
    return pickRandom([
      `${done} tasks done — you're on fire today 🔥`,
      "Look at you go! Incredible momentum 💪",
      "You're making serious progress today ⚡",
    ]);
  }
  if (done >= 3) {
    return pickRandom([
      "You're doing great — keep the flow going 🌊",
      "3+ tasks done. That's a solid day already 👏",
      "Nice rhythm! One task at a time 🎯",
    ]);
  }
  if (overdue > 0 && pending > 0) {
    return pickRandom([
      "A few things slipped — that's okay, start here 💛",
      "Yesterday's tasks? Today's fresh start 🌅",
      "Overdue doesn't mean over. You've got this 🤝",
    ]);
  }
  if (pending <= 3 && pending > 0) {
    return pickRandom([
      `Just ${pending} task${pending > 1 ? 's' : ''} — totally doable 😊`,
      "3 tasks is enough for a great day ✌️",
      "Small list, big impact. Quality over quantity 🌟",
    ]);
  }
  if (pending > 3) {
    return pickRandom([
      "Focus on the top 3 — the rest can wait 🧘",
      "Progress > perfection. One step at a time 🚶",
      "You don't have to do it all today. Just start 💙",
      "Pick one task. Finish it. Repeat. 🔁",
    ]);
  }
  // No tasks at all
  return pickRandom([
    "A blank canvas. What will you create today? 🎨",
    "No tasks yet — take a moment to plan your day 📝",
    "Ready when you are. Add your first task 🚀",
  ]);
}

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function getTop3Tasks() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayMs = today.getTime();

  // Gather all pending tasks across all lists
  const pending = [];
  data.lists.forEach((list) => {
    list.tasks.forEach((task) => {
      if (!task.done) pending.push(task);
    });
  });

  // Score each task
  const scored = pending.map((task) => {
    let score = 0;

    // Overdue = highest urgency
    if (task.due) {
      const dueDate = new Date(task.due + "T00:00:00");
      const diffDays = Math.round((dueDate - todayMs) / 86400000);
      if (diffDays < 0) {
        score += 100 + Math.min(Math.abs(diffDays), 30); // more overdue = higher
      } else if (diffDays === 0) {
        score += 80; // due today
      } else if (diffDays === 1) {
        score += 60; // due tomorrow
      } else if (diffDays <= 3) {
        score += 40; // due within 3 days
      } else if (diffDays <= 7) {
        score += 20; // due this week
      }
    }

    // Priority boost
    const pw = { high: 30, medium: 15, low: 5 };
    score += pw[task.priority] || 0;

    // Time-based boost (tasks with a time set today)
    if (task.time && (!task.due || task.due === todayStr2())) {
      score += 10;
    }

    return { task, score };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, 3);
}

function renderTop3() {
  const section = document.getElementById("top3Section");
  const list = document.getElementById("top3List");
  if (!section || !list) return;

  const top3 = getTop3Tasks();
  if (top3.length === 0) {
    list.innerHTML = `<div class="top3-empty">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="28" height="28" style="color:var(--text3);margin-bottom:4px"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="10"/></svg>
      <span>No priorities set for today</span>
    </div>`;
    return;
  }

  const today = todayStr2();

  list.innerHTML = top3.map((item, i) => {
    const t = item.task;
    const rank = i + 1;
    let metaParts = [];
    if (t.due) {
      const dueDate = new Date(t.due + "T00:00:00");
      const todayDate = new Date(today + "T00:00:00");
      const diff = Math.round((dueDate - todayDate) / 86400000);
      if (diff < 0) metaParts.push(`<span class="top3-overdue">Overdue ${Math.abs(diff)}d</span>`);
      else if (diff === 0) metaParts.push("Due today");
      else if (diff === 1) metaParts.push("Due tomorrow");
      else metaParts.push("Due " + formatDate(t.due));
    }
    if (t.time) metaParts.push(formatTime(t.time));
    if (t.category) metaParts.push(escapeHtml(t.category));

    return `<div class="top3-item">
      <div class="top3-rank r${rank}">${rank}</div>
      <div class="top3-info">
        <div class="top3-title">${escapeHtml(t.title)}</div>
        <div class="top3-meta">
          <span class="top3-badge bp-${t.priority}">${t.priority}</span>
          ${metaParts.join(" · ")}
        </div>
      </div>
    </div>`;
  }).join("");
}

function renderAll() {
  renderTabs();
  renderTasks();
  if (currentMode === "today") renderTodayView();
}

// ===== Add / Edit =====
function resetForm() {
  editingId = null;
  titleInput.value = "";
  dueInput.value = "";
  timeInput.value = "";
  priorityInput.value = "medium";
  categoryInput.value = "";
  formTitle.textContent = "Add New Task";
  saveBtn.textContent = "Add Task";
  cancelBtn.style.display = "none";
}

saveBtn.addEventListener("click", () => {
  const title = titleInput.value.trim();
  if (!title) {
    titleInput.focus();
    titleInput.style.borderColor = "var(--danger)";
    setTimeout(() => titleInput.style.borderColor = "", 1500);
    return;
  }

  const list = getActiveList();
  if (!list) return;

  if (editingId) {
    const task = list.tasks.find((t) => t.id === editingId);
    if (task) {
      task.title    = title;
      task.due      = dueInput.value || null;
      task.time     = timeInput.value || null;
      task.priority = priorityInput.value;
      task.category = categoryInput.value.trim() || null;
      clearNotifiedFor(task.id);
    }
  } else {
    list.tasks.push({
      id:       generateId(),
      title:    title,
      due:      dueInput.value || null,
      time:     timeInput.value || null,
      priority: priorityInput.value,
      category: categoryInput.value.trim() || null,
      done:     false,
      created:  Date.now(),
    });
  }

  save();
  resetForm();
  renderAll();
});

cancelBtn.addEventListener("click", () => { resetForm(); });

titleInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveBtn.click();
});

// ===== Toggle Done / Edit / Delete =====
taskList.addEventListener("click", (e) => {
  const list = getActiveList();
  if (!list) return;

  // Subtask check
  const subCheck = e.target.closest(".subtask-check");
  if (subCheck) {
    const task = list.tasks.find((t) => t.id === subCheck.dataset.taskId);
    if (task && task.subtasks) {
      const sub = task.subtasks.find((s) => s.id === subCheck.dataset.subId);
      if (sub) { sub.done = !sub.done; save(); renderAll(); }
    }
    return;
  }

  const check = e.target.closest(".task-check");
  if (check) {
    const task = list.tasks.find((t) => t.id === check.dataset.id);
    if (task) {
      task.done = !task.done;
      task.completedAt = task.done ? Date.now() : null;
      save(); renderAll();
    }
    return;
  }

  const editBtn = e.target.closest(".btn-edit");
  if (editBtn) {
    const task = list.tasks.find((t) => t.id === editBtn.dataset.id);
    if (task) {
      editingId = task.id;
      titleInput.value    = task.title;
      dueInput.value      = task.due || "";
      timeInput.value     = task.time || "";
      priorityInput.value = task.priority;
      categoryInput.value = task.category || "";
      formTitle.textContent = "Edit Task";
      saveBtn.textContent   = "Update Task";
      cancelBtn.style.display = "inline-flex";
      titleInput.focus();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
    return;
  }

  const delBtn = e.target.closest(".btn-del");
  if (delBtn) {
    deletingId = delBtn.dataset.id;
    deleteModal.classList.add("active");
    return;
  }
});

taskList.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === " ") {
    const check = e.target.closest(".task-check");
    if (check) { e.preventDefault(); check.click(); }
  }
});

// ===== Delete task =====
confirmDelete.addEventListener("click", () => {
  if (deletingId) {
    const list = getActiveList();
    if (list) {
      list.tasks = list.tasks.filter((t) => t.id !== deletingId);
      save();
      renderAll();
    }
    deletingId = null;
  }
  deleteModal.classList.remove("active");
});

cancelDelete.addEventListener("click", () => {
  deletingId = null;
  deleteModal.classList.remove("active");
});

deleteModal.addEventListener("click", (e) => {
  if (e.target === deleteModal) { deletingId = null; deleteModal.classList.remove("active"); }
});

// ===== Filters =====
searchInput.addEventListener("input", renderTasks);
filterStatus.addEventListener("change", renderTasks);
filterPriority.addEventListener("change", renderTasks);
filterCategory.addEventListener("change", renderTasks);
sortBy.addEventListener("change", renderTasks);

// ===== Brain Dump =====
dumpToggle.addEventListener("click", () => {
  const isOpen = dumpBody.style.display !== "none";
  dumpBody.style.display = isOpen ? "none" : "block";
  dumpToggle.classList.toggle("open", !isOpen);
});

// Auto-correct
autocorrectBtn.addEventListener("click", async () => {
  const text = dumpText.value.trim();
  if (!text) { dumpText.focus(); return; }

  dumpStatus.textContent = "Correcting...";
  dumpStatus.className = "dump-status loading";
  autocorrectBtn.disabled = true;

  try {
    const resp = await fetch("/api/autocorrect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    if (!resp.ok) throw new Error("Server error");
    const data = await resp.json();
    dumpText.value = data.corrected;
    dumpStatus.textContent = "✓ Corrected!";
    dumpStatus.className = "dump-status";
  } catch (err) {
    dumpStatus.textContent = "Failed to auto-correct";
    dumpStatus.className = "dump-status error";
  }
  autocorrectBtn.disabled = false;
  setTimeout(() => { dumpStatus.textContent = ""; }, 3000);
});

function parseDumpText(text) {
  // Split by newlines, bullets, numbers, semicolons
  let items = text
    .split(/[\n\r]+/)                       // split by newlines
    .flatMap((line) => line.split(/[;]/))   // split by semicolons
    .flatMap((line) => {
      // Split by numbered lists: "1. task 2. task"
      const numbered = line.split(/(?:^|\s)(?:\d+[\.\)]\s)/);
      if (numbered.length > 1) return numbered;
      return [line];
    })
    .flatMap((line) => {
      // Split by bullet chars
      return line.split(/(?:^|\s)[\-\*•]\s/);
    })
    .flatMap((line) => {
      // Split by "and" / "&" / commas when they separate independent tasks
      // Only split on commas followed by a verb-like start or action words
      const parts = line.split(/,\s*(?:and\s+)?|(?:^|\s)and\s+|(?:^|\s)&\s+/i);
      if (parts.length > 1) return parts;
      return [line];
    })
    .map((s) => s.replace(/^[\s\-\*•\d\.\)]+/, "").trim())   // clean prefixes
    .map((s) => s.replace(/[\.!]+$/, "").trim())              // clean trailing punctuation
    .filter((s) => s.length >= 3 && s.length <= 200);         // filter too short/long

  // Capitalize first letter
  items = items.map((s) => s.charAt(0).toUpperCase() + s.slice(1));

  // Deduplicate
  const seen = new Set();
  return items.filter((s) => {
    const key = s.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

parseDumpBtn.addEventListener("click", () => {
  const text = dumpText.value.trim();
  if (!text) {
    dumpText.focus();
    return;
  }

  const tasks = parseDumpText(text);
  if (tasks.length === 0) {
    dumpPreview.style.display = "none";
    return;
  }

  dumpList.innerHTML = "";
  tasks.forEach((task, i) => {
    const item = document.createElement("div");
    item.className = "dump-item";
    item.dataset.level = "0";
    item.innerHTML = `
      <button class="dump-indent-btn" data-action="indent" title="Make subtask">→</button>
      <button class="dump-indent-btn" data-action="outdent" title="Make parent">←</button>
      <label class="dump-item-label">
        <input type="checkbox" checked data-index="${i}">
        <span>${escapeHtml(task)}</span>
      </label>
    `;
    dumpList.appendChild(item);
  });

  dumpSelectAll.checked = true;
  dumpPreview.style.display = "block";
});

// Indent/outdent in dump preview
dumpList.addEventListener("click", (e) => {
  const btn = e.target.closest(".dump-indent-btn");
  if (!btn) return;
  e.preventDefault();
  const item = btn.closest(".dump-item");
  let level = parseInt(item.dataset.level) || 0;
  if (btn.dataset.action === "indent" && level === 0) {
    // Only indent if there's a parent above
    const prev = item.previousElementSibling;
    if (prev && parseInt(prev.dataset.level) === 0) {
      level = 1;
    }
  } else if (btn.dataset.action === "outdent" && level > 0) {
    level = 0;
  }
  item.dataset.level = level;
  item.style.paddingLeft = level ? "32px" : "";
});

dumpSelectAll.addEventListener("change", () => {
  const checkboxes = dumpList.querySelectorAll('input[type="checkbox"]');
  checkboxes.forEach((cb) => cb.checked = dumpSelectAll.checked);
});

addDumpTasksBtn.addEventListener("click", () => {
  const list = getActiveList();
  if (!list) return;

  const items = dumpList.querySelectorAll(".dump-item");
  if (items.length === 0) return;

  // Build parent-subtask structure
  let lastParentTask = null;

  items.forEach((item) => {
    const cb = item.querySelector('input[type="checkbox"]');
    if (!cb.checked) return;
    const span = item.querySelector("span");
    if (!span) return;
    const level = parseInt(item.dataset.level) || 0;
    const title = span.textContent;

    if (level === 0) {
      // Parent task
      const task = {
        id:       generateId(),
        title:    title,
        due:      null,
        priority: "medium",
        category: null,
        done:     false,
        created:  Date.now(),
        subtasks: [],
      };
      list.tasks.push(task);
      lastParentTask = task;
    } else if (lastParentTask) {
      // Subtask
      lastParentTask.subtasks.push({
        id:   generateId(),
        title: title,
        done:  false,
      });
    }
  });

  save();
  renderAll();

  // Reset dump
  dumpText.value = "";
  dumpPreview.style.display = "none";
  dumpList.innerHTML = "";
});

// ===== Init =====
initTheme();
load();
loadSystems();
renderAll();

// Start on Today view — hide tasks panels
tasksViewEls.tabs.style.display = "none";
tasksViewEls.layout.style.display = "none";
renderTodayView();

// ===== User Menu Dropdown =====
const userMenuEl = document.getElementById("userMenu");
const userAvatarEl = document.getElementById("userAvatar");
if (userMenuEl && userAvatarEl) {
  userAvatarEl.addEventListener("click", (e) => {
    e.stopPropagation();
    userMenuEl.classList.toggle("open");
  });
  document.addEventListener("click", () => userMenuEl.classList.remove("open"));
}

// ===== Notifications =====
const NOTIFIED_KEY = "todo_app_notified";

function loadNotified() {
  try {
    const raw = JSON.parse(localStorage.getItem(NOTIFIED_KEY));
    if (raw && raw.day === todayStr2()) {
      return { day: raw.day, ids: new Set(raw.ids) };
    }
  } catch {}
  return { day: todayStr2(), ids: new Set() };
}

function saveNotified() {
  localStorage.setItem(NOTIFIED_KEY, JSON.stringify({
    day: notifState.day,
    ids: [...notifState.ids],
  }));
  saveToCloud("notified", { day: notifState.day, ids: [...notifState.ids] });
}

function clearNotifiedFor(taskId) {
  notifState.ids.delete("task:" + taskId);
  saveNotified();
}

let notifState = loadNotified();

function todayStr2() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
}

function currentHHMM() {
  const d = new Date();
  return String(d.getHours()).padStart(2,"0") + ":" + String(d.getMinutes()).padStart(2,"0");
}

function requestNotifPermission() {
  if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission().then(updateNotifDot);
  }
}

function updateNotifDot() {
  const dot = document.getElementById("notifDot");
  if (!dot || !("Notification" in window)) return;
  if (Notification.permission === "granted") {
    dot.className = "notif-dot active";
    document.getElementById("notifToggle").title = "Reminders enabled";
  } else if (Notification.permission === "denied") {
    dot.className = "notif-dot denied";
    document.getElementById("notifToggle").title = "Reminders blocked — enable in browser settings";
  } else {
    dot.className = "notif-dot";
    document.getElementById("notifToggle").title = "Click to enable reminders";
  }
}

document.getElementById("notifToggle").addEventListener("click", () => {
  if (!("Notification" in window)) {
    alert("Your browser does not support notifications.");
    return;
  }
  if (Notification.permission === "default") {
    Notification.requestPermission().then(updateNotifDot);
  } else if (Notification.permission === "denied") {
    alert("Notifications are blocked.\n\nTo fix:\n1. Click the lock/info icon in the address bar\n2. Find 'Notifications' and set to 'Allow'\n3. Refresh the page");
  } else {
    // Send a test notification
    sendNotification(
      "✅ Reminders Working!",
      "You'll get notified when a task or system is due.",
      "test-notif"
    );
  }
});

function sendNotification(title, body, tag) {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  const n = new Notification(title, {
    body: body,
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>✅</text></svg>",
    tag: tag,
    requireInteraction: true,
  });
  n.onclick = () => { window.focus(); n.close(); };
}

function checkReminders() {
  // Reset tracked set at midnight
  const day = todayStr2();
  if (day !== notifState.day) {
    notifState = { day: day, ids: new Set() };
    saveNotified();
  }

  const now = currentHHMM();

  // Check tasks
  data.lists.forEach((list) => {
    list.tasks.forEach((task) => {
      if (task.done || !task.time) return;
      // Only remind if task is for today (or has no date)
      if (task.due && task.due !== day) return;
      const key = "task:" + task.id;
      if (notifState.ids.has(key)) return;
      // Fire if task time is now or has just passed (within same day)
      if (task.time <= now) {
        notifState.ids.add(key);
        saveNotified();
        sendNotification(
          "⏰ Task Reminder",
          task.title + (task.due ? " — Due " + formatDate(task.due) : ""),
          key
        );
      }
    });
  });

  // Check systems
  systems.forEach((sys) => {
    if (!sys.time) return;
    const key = "sys:" + sys.id;
    if (notifState.ids.has(key)) return;
    // Don't remind if already checked in today
    if (sys.checkins && sys.checkins.includes(day)) return;
    if (sys.time <= now) {
      notifState.ids.add(key);
      saveNotified();
      sendNotification(
        "🔁 System Reminder",
        sys.name + " — Time to check in!",
        key
      );
    }
  });
}

requestNotifPermission();
updateNotifDot();
setInterval(checkReminders, 30000); // check every 30 seconds
checkReminders(); // initial check

// ===== Mode Toggle =====
function switchMode(mode) {
  currentMode = mode;
  modeBtns.forEach((b) => b.classList.toggle("active", b.dataset.mode === mode));
  document.querySelectorAll(".nav-item").forEach((n) => n.classList.toggle("active", n.dataset.mode === mode));

  todayView.style.display = mode === "today" ? "block" : "none";
  tasksViewEls.tabs.style.display = mode === "tasks" ? "" : "none";
  tasksViewEls.layout.style.display = mode === "tasks" ? "" : "none";
  focusViewEl.style.display = mode === "focus" ? "block" : "none";
  insightsView.style.display = mode === "insights" ? "block" : "none";
  systemsView.style.display = mode === "systems" ? "block" : "none";

  if (mode === "today") renderTodayView();
  if (mode === "focus") populateFocusSelect();
  if (mode === "insights") renderInsights();
  if (mode === "systems") renderSystems();
}

modeBtns.forEach((btn) => {
  btn.addEventListener("click", () => switchMode(btn.dataset.mode));
});

// Nav sidebar
const navMenuBtn = document.getElementById("navMenuBtn");
const navSidebar = document.getElementById("navSidebar");
const navOverlay = document.getElementById("navOverlay");
const navCloseBtn = document.getElementById("navCloseBtn");
const navItems = document.querySelectorAll(".nav-item");

function openNav() {
  navSidebar.classList.add("open");
  navOverlay.classList.add("open");
}
function closeNav() {
  navSidebar.classList.remove("open");
  navOverlay.classList.remove("open");
}

navMenuBtn.addEventListener("click", openNav);
navCloseBtn.addEventListener("click", closeNav);
navOverlay.addEventListener("click", closeNav);

navItems.forEach((item) => {
  item.addEventListener("click", () => {
    const mode = item.dataset.mode;
    modeBtns.forEach((b) => b.classList.remove("active"));
    navItems.forEach((n) => n.classList.remove("active"));
    item.classList.add("active");
    closeNav();
    switchMode(mode);
  });
});

// "Go to Tasks" button
document.getElementById("goToTasksBtn").addEventListener("click", () => switchMode("tasks"));

// Today Brain Dump
document.getElementById("todayDumpBtn").addEventListener("click", () => {
  const textarea = document.getElementById("todayDumpText");
  const statusEl = document.getElementById("todayDumpStatus");
  const text = textarea.value.trim();
  if (!text) { textarea.focus(); return; }

  const parsed = parseDumpText(text);
  if (parsed.length === 0) {
    statusEl.textContent = "Couldn't find any tasks — try rephrasing";
    statusEl.style.color = "var(--red)";
    setTimeout(() => { statusEl.textContent = ""; }, 3000);
    return;
  }

  const list = getActiveList();
  if (!list) return;

  parsed.forEach((title) => {
    list.tasks.push({
      id: generateId(),
      title: title,
      due: null,
      time: null,
      priority: "medium",
      category: null,
      done: false,
      created: Date.now(),
    });
  });

  save();
  renderAll();
  renderTodayView();

  textarea.value = "";
  statusEl.style.color = "var(--green)";
  statusEl.textContent = `✓ ${parsed.length} task${parsed.length > 1 ? "s" : ""} added!`;
  setTimeout(() => { statusEl.textContent = ""; }, 3000);
});

// ===== Focus Mode =====
const FOCUS_DURATION = 25 * 60; // 25 minutes in seconds

function populateFocusSelect() {
  const sel = document.getElementById("focusTaskSelect");
  if (!sel) return;
  const prevVal = sel.value;
  sel.innerHTML = '<option value="">Pick a task to focus on...</option>';

  // Add top 3 first, then remaining pending
  const top3 = getTop3Tasks();
  const top3Ids = new Set(top3.map(t => t.task.id));

  if (top3.length > 0) {
    const grp1 = document.createElement("optgroup");
    grp1.label = "⭐ Top Priorities";
    top3.forEach(({ task }) => {
      const opt = document.createElement("option");
      opt.value = task.id;
      opt.textContent = task.title;
      grp1.appendChild(opt);
    });
    sel.appendChild(grp1);
  }

  const others = [];
  data.lists.forEach(l => l.tasks.forEach(t => {
    if (!t.done && !top3Ids.has(t.id)) others.push(t);
  }));
  if (others.length > 0) {
    const grp2 = document.createElement("optgroup");
    grp2.label = "All Tasks";
    others.forEach(t => {
      const opt = document.createElement("option");
      opt.value = t.id;
      opt.textContent = t.title;
      grp2.appendChild(opt);
    });
    sel.appendChild(grp2);
  }
  sel.value = prevVal;
}

function findTaskById(id) {
  for (const list of data.lists) {
    const t = list.tasks.find(t => t.id === id);
    if (t) return t;
  }
  return null;
}

function updateFocusRing() {
  const ring = document.getElementById("focusRingProgress");
  if (!ring) return;
  const circumference = 2 * Math.PI * 52; // r=52
  const pct = focusRemaining / FOCUS_DURATION;
  ring.style.strokeDashoffset = circumference * pct;
}

function updateFocusTimer() {
  const el = document.getElementById("focusTimer");
  if (!el) return;
  const m = Math.floor(focusRemaining / 60);
  const s = focusRemaining % 60;
  el.textContent = `${m}:${String(s).padStart(2, "0")}`;
}

function startFocus() {
  const sel = document.getElementById("focusTaskSelect");
  focusTaskId = sel ? sel.value : null;
  const task = focusTaskId ? findTaskById(focusTaskId) : null;

  document.getElementById("focusIdle").style.display = "none";
  document.getElementById("focusDone").style.display = "none";
  document.getElementById("focusActive").style.display = "block";

  const nameEl = document.getElementById("focusTaskName");
  nameEl.textContent = task ? task.title : "Free focus session";
  nameEl.style.display = task ? "inline-block" : "none";

  focusRemaining = FOCUS_DURATION;
  focusPaused = false;
  document.getElementById("focusSection").classList.remove("paused");
  updatePauseBtn();
  updateFocusTimer();
  updateFocusRing();

  focusInterval = setInterval(() => {
    if (focusPaused) return;
    focusRemaining--;
    updateFocusTimer();
    updateFocusRing();
    if (focusRemaining <= 0) {
      clearInterval(focusInterval);
      focusInterval = null;
      completeFocus();
    }
  }, 1000);
}

function completeFocus() {
  document.getElementById("focusActive").style.display = "none";
  document.getElementById("focusDone").style.display = "block";
  const task = focusTaskId ? findTaskById(focusTaskId) : null;
  document.getElementById("focusDoneSub").textContent = task
    ? `Great focus on "${task.title}"`
    : "25 minutes of deep work — well done!";
  document.getElementById("focusMarkDoneBtn").style.display = task ? "" : "none";

  // Notification
  sendNotification("🎉 Focus Session Complete!",
    task ? `Done focusing on: ${task.title}` : "25 minutes of deep work completed!",
    "focus-done");
}

function resetFocus() {
  clearInterval(focusInterval);
  focusInterval = null;
  focusRemaining = FOCUS_DURATION;
  focusPaused = false;
  focusTaskId = null;
  document.getElementById("focusSection").classList.remove("paused");
  document.getElementById("focusActive").style.display = "none";
  document.getElementById("focusDone").style.display = "none";
  document.getElementById("focusIdle").style.display = "block";
  updateFocusTimer();
  updateFocusRing();
  populateFocusSelect();
}

function updatePauseBtn() {
  const btn = document.getElementById("focusPauseBtn");
  if (!btn) return;
  if (focusPaused) {
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="20" height="20"><polygon points="5 3 19 12 5 21 5 3"/></svg>';
    btn.title = "Resume";
  } else {
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="20" height="20"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>';
    btn.title = "Pause";
  }
}

document.getElementById("focusStartBtn").addEventListener("click", startFocus);

document.getElementById("focusPauseBtn").addEventListener("click", () => {
  focusPaused = !focusPaused;
  document.getElementById("focusSection").classList.toggle("paused", focusPaused);
  updatePauseBtn();
});

document.getElementById("focusCancelBtn").addEventListener("click", resetFocus);

document.getElementById("focusAgainBtn").addEventListener("click", resetFocus);

document.getElementById("focusMarkDoneBtn").addEventListener("click", () => {
  if (focusTaskId) {
    const task = findTaskById(focusTaskId);
    if (task) { task.done = true; task.completedAt = Date.now(); save(); renderAll(); }
  }
  resetFocus();
  renderTodayView();
});

// ===== Systems Engine =====
function todayStr() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
}

function getWeekStart(date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Monday
  return new Date(d.setDate(diff));
}

function getWeekDates() {
  const start = getWeekStart(new Date());
  const dates = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    dates.push(d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0"));
  }
  return dates;
}

function getStreakCount(checkins) {
  if (!checkins.length) return 0;
  const sorted = [...new Set(checkins)].sort().reverse();
  const today = todayStr();
  let streak = 0;
  let expected = new Date(today + "T00:00:00");

  // Allow today or yesterday as start
  if (sorted[0] !== today) {
    const yesterday = new Date(expected);
    yesterday.setDate(yesterday.getDate() - 1);
    const yStr = yesterday.getFullYear() + "-" + String(yesterday.getMonth()+1).padStart(2,"0") + "-" + String(yesterday.getDate()).padStart(2,"0");
    if (sorted[0] !== yStr) return 0;
    expected = yesterday;
  }

  for (const dateStr of sorted) {
    const expStr = expected.getFullYear() + "-" + String(expected.getMonth()+1).padStart(2,"0") + "-" + String(expected.getDate()).padStart(2,"0");
    if (dateStr === expStr) {
      streak++;
      expected.setDate(expected.getDate() - 1);
    } else if (dateStr < expStr) {
      break;
    }
  }
  return streak;
}

function getWeeklyRate(sys) {
  const weekDates = getWeekDates();
  const count = weekDates.filter((d) => sys.checkins.includes(d)).length;
  return { count, target: sys.freq };
}

function getConsistencyPct(sys) {
  if (!sys.created) return 0;
  const start = new Date(sys.created);
  const now = new Date();
  const weeks = Math.max(1, Math.ceil((now - start) / (7 * 86400000)));
  const totalExpected = weeks * sys.freq;
  return Math.min(100, Math.round((sys.checkins.length / totalExpected) * 100));
}

function buildIdentity(sys) {
  const rate = getWeeklyRate(sys);
  const freqLabel = sys.freq === 7 ? "every day" : `${sys.freq}x/week`;
  return `"You are a person who ${sys.name.toLowerCase()} ${freqLabel}"`;
}

function buildHeatmap(sys) {
  // Last 12 weeks (84 days)
  const cells = [];
  const today = new Date();
  const checkinSet = new Set(sys.checkins);
  for (let i = 83; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const ds = d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
    const checked = checkinSet.has(ds);
    // Count checkins in surrounding 3 days for intensity
    let nearby = 0;
    for (let j = -1; j <= 1; j++) {
      const nd = new Date(d);
      nd.setDate(d.getDate() + j);
      const ns = nd.getFullYear() + "-" + String(nd.getMonth()+1).padStart(2,"0") + "-" + String(nd.getDate()).padStart(2,"0");
      if (checkinSet.has(ns)) nearby++;
    }
    let level = "";
    if (checked) level = nearby >= 3 ? "l3" : nearby >= 2 ? "l2" : "l1";
    const dayNames = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
    const title = dayNames[d.getDay()] + " " + d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    cells.push(`<div class="heatmap-cell ${level}" title="${title}${checked ? ' ✓' : ''}"></div>`);
  }
  return cells.join("");
}

function renderSystems() {
  sysList.innerHTML = "";
  if (systems.length === 0) {
    sysEmptyState.style.display = "block";
    return;
  }
  sysEmptyState.style.display = "none";

  const today = todayStr();
  const weekDates = getWeekDates();

  systems.forEach((sys) => {
    const streak = getStreakCount(sys.checkins);
    const weekly = getWeeklyRate(sys);
    const consistency = getConsistencyPct(sys);
    const checkedToday = sys.checkins.includes(today);
    const identity = buildIdentity(sys);

    const card = document.createElement("div");
    card.className = "sys-card";

    // Week dots
    const weekDotsHtml = weekDates.map((d) => {
      const filled = sys.checkins.includes(d);
      const isToday = d === today;
      return `<div class="sys-week-dot${filled ? ' filled' : ''}${isToday ? ' today' : ''}" title="${d}"></div>`;
    }).join("");

    card.innerHTML = `
      <div class="sys-card-top">
        <div class="sys-card-info">
          <div class="sys-card-name">${escapeHtml(sys.name)}</div>
          ${sys.time ? `<div class="sys-card-time"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg> ${formatTime(sys.time)}</div>` : ''}
          <div class="sys-identity">${identity}</div>
          <div class="sys-stats-row">
            <div class="sys-stat">
              <span class="sys-stat-val streak">${streak} day${streak !== 1 ? 's' : ''}</span>
              <span class="sys-stat-label">Current Streak</span>
            </div>
            <div class="sys-stat">
              <span class="sys-stat-val rate">${weekly.count}/${weekly.target}</span>
              <span class="sys-stat-label">This Week</span>
            </div>
            <div class="sys-stat">
              <span class="sys-stat-val">${consistency}%</span>
              <span class="sys-stat-label">Consistency</span>
            </div>
          </div>
        </div>
        <div class="sys-card-actions">
          <button class="sys-del" data-sys-id="${sys.id}" title="Delete system">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
          </button>
        </div>
      </div>
      <div class="sys-checkin-area">
        <button class="sys-checkin-btn${checkedToday ? ' checked-in' : ''}" data-sys-id="${sys.id}">
          ${checkedToday ? '✓ Done today' : '✓ Check in'}
        </button>
        ${checkedToday ? '<span class="sys-checkin-msg">Nice work! Keep it going.</span>' : ''}
        <div class="sys-week-dots">${weekDotsHtml}</div>
      </div>
      <div class="sys-heatmap-area">
        <div class="sys-heatmap-label">Last 12 weeks</div>
        <div class="heatmap">${buildHeatmap(sys)}</div>
      </div>
    `;
    sysList.appendChild(card);
  });
}

// Add system
addSystemBtn.addEventListener("click", () => {
  const name = sysNameInput.value.trim();
  if (!name) {
    sysNameInput.focus();
    sysNameInput.style.borderColor = "var(--danger)";
    setTimeout(() => sysNameInput.style.borderColor = "", 1500);
    return;
  }
  systems.push({
    id: generateId(),
    name: name,
    time: sysTimeInput.value || null,
    freq: parseInt(sysFreqInput.value),
    checkins: [],
    created: todayStr(),
  });
  sysNameInput.value = "";
  sysTimeInput.value = "";
  saveSystems();
  renderSystems();
});

sysNameInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") addSystemBtn.click();
});

// Check-in + delete
sysList.addEventListener("click", (e) => {
  const checkinBtn = e.target.closest(".sys-checkin-btn");
  if (checkinBtn && !checkinBtn.classList.contains("checked-in")) {
    const sys = systems.find((s) => s.id === checkinBtn.dataset.sysId);
    if (sys) {
      const today = todayStr();
      if (!sys.checkins.includes(today)) {
        sys.checkins.push(today);
        saveSystems();
        renderSystems();
      }
    }
    return;
  }

  const delBtn = e.target.closest(".sys-del");
  if (delBtn) {
    deletingSystemId = delBtn.dataset.sysId;
    deleteSystemModal.classList.add("active");
    return;
  }
});

// Delete system modal
confirmDeleteSystem.addEventListener("click", () => {
  if (deletingSystemId) {
    systems = systems.filter((s) => s.id !== deletingSystemId);
    deletingSystemId = null;
    saveSystems();
    renderSystems();
  }
  deleteSystemModal.classList.remove("active");
});
cancelDeleteSystem.addEventListener("click", () => {
  deletingSystemId = null;
  deleteSystemModal.classList.remove("active");
});
deleteSystemModal.addEventListener("click", (e) => {
  if (e.target === deleteSystemModal) { deletingSystemId = null; deleteSystemModal.classList.remove("active"); }
});
