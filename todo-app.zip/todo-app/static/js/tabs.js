/* =============================================================
   TABS.JS — List Tab Rendering, Context Menu (Rename/Delete),
   Add New List, Rename Modal, Delete List Modal
   ============================================================= */

/**
 * Render all list tabs in the tabs bar.
 * Shows pending task count per tab and highlights the active tab.
 */
function renderTabs() {
  tabsScroll.innerHTML = "";
  data.lists.forEach((list) => {
    const tab = document.createElement("button");
    tab.className = "tab" + (list.id === data.activeListId ? " active" : "");
    const pending = list.tasks.filter((t) => !t.done).length;
    tab.innerHTML = `
      <span class="tab-name">${escapeHtml(list.name)}</span>
      <span class="tab-count">${pending}</span>
      <span class="tab-menu-btn" data-list-id="${list.id}" title="List options">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="6" r="1.5"/><circle cx="12" cy="18" r="1.5"/></svg>
      </span>
    `;
    tab.addEventListener("click", (e) => {
      if (e.target.closest(".tab-menu-btn")) return;
      data.activeListId = list.id;
      save();
      resetForm();
      renderAll();
    });
    tabsScroll.appendChild(tab);
  });
}

// ===== Tab Context Menu =====

/** Reference to the currently open context menu */
let openMenu = null;

/**
 * Close the currently open tab context menu.
 */
function closeMenu() {
  if (openMenu) { openMenu.remove(); openMenu = null; }
  document.removeEventListener("click", closeMenu);
}

/**
 * Handle clicks on tab menu buttons to show rename/delete options.
 */
tabsScroll.addEventListener("click", (e) => {
  const menuBtn = e.target.closest(".tab-menu-btn");
  if (!menuBtn) return;
  e.stopPropagation();
  closeMenu();
  const listId = menuBtn.dataset.listId;
  const menu = document.createElement("div");
  menu.className = "tab-context-menu";
  menu.innerHTML = `
    <button data-action="rename">&#9998; Rename</button>
    <button data-action="delete" class="danger">&#128465; Delete</button>
  `;
  menuBtn.closest(".tab").appendChild(menu);
  openMenu = menu;

  menu.addEventListener("click", (ev) => {
    const action = ev.target.closest("button")?.dataset.action;
    if (action === "rename") {
      renamingListId = listId;
      const list = data.lists.find((l) => l.id === listId);
      renameInput.value = list ? list.name : "";
      renameModal.classList.add("active");
      setTimeout(() => renameInput.focus(), 50);
    } else if (action === "delete") {
      if (data.lists.length <= 1) {
        alert("You need at least one list.");
      } else {
        deletingListId = listId;
        deleteListModal.classList.add("active");
      }
    }
    closeMenu();
  });

  setTimeout(() => document.addEventListener("click", closeMenu), 0);
});

// ===== Add New List =====
addListBtn.addEventListener("click", () => {
  const name = prompt("Enter list name:");
  if (!name || !name.trim()) return;
  const newList = { id: generateId(), name: name.trim(), tasks: [] };
  data.lists.push(newList);
  data.activeListId = newList.id;
  save();
  resetForm();
  renderAll();
});

// ===== Rename List Modal =====
confirmRename.addEventListener("click", () => {
  const name = renameInput.value.trim();
  if (!name) return;
  const list = data.lists.find((l) => l.id === renamingListId);
  if (list) { list.name = name; save(); renderAll(); }
  renamingListId = null;
  renameModal.classList.remove("active");
});
cancelRename.addEventListener("click", () => {
  renamingListId = null;
  renameModal.classList.remove("active");
});
renameModal.addEventListener("click", (e) => {
  if (e.target === renameModal) { renamingListId = null; renameModal.classList.remove("active"); }
});
renameInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") confirmRename.click();
});

// ===== Delete List Modal =====
confirmDeleteList.addEventListener("click", () => {
  if (deletingListId && data.lists.length > 1) {
    data.lists = data.lists.filter((l) => l.id !== deletingListId);
    if (data.activeListId === deletingListId) {
      data.activeListId = data.lists[0].id;
    }
    deletingListId = null;
    save();
    resetForm();
    renderAll();
  }
  deleteListModal.classList.remove("active");
});
cancelDeleteList.addEventListener("click", () => {
  deletingListId = null;
  deleteListModal.classList.remove("active");
});
deleteListModal.addEventListener("click", (e) => {
  if (e.target === deleteListModal) { deletingListId = null; deleteListModal.classList.remove("active"); }
});
