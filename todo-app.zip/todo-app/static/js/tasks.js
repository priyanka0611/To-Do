/* =============================================================
   TASKS.JS — Task CRUD, Rendering, Filtering, Categories,
   Stats, Brain Dump (Tasks View)
   ============================================================= */

// ===== Categories =====

/**
 * Get all unique categories from the active list's tasks.
 * @returns {string[]} Sorted array of category names
 */
function getCategories() {
  const cats = new Set();
  getTasks().forEach((t) => { if (t.category) cats.add(t.category); });
  return [...cats].sort();
}

/**
 * Update category filter dropdown and datalist suggestions.
 */
function updateCategoryUI() {
  const cats = getCategories();
  const current = filterCategory.value;
  filterCategory.innerHTML = '<option value="all">All Categories</option>';
  cats.forEach((c) => {
    const opt = document.createElement("option");
    opt.value = c;
    opt.textContent = c;
    filterCategory.appendChild(opt);
  });
  filterCategory.value = current;
  categorySugg.innerHTML = "";
  cats.forEach((c) => {
    const opt = document.createElement("option");
    opt.value = c;
    categorySugg.appendChild(opt);
  });
}

// ===== Stats =====

/**
 * Update the stats bar with total, pending, done, and overdue counts.
 */
function updateStats() {
  const tasks = getTasks();
  const total   = tasks.length;
  const done    = tasks.filter((t) => t.done).length;
  const pending = total - done;
  const overdue = tasks.filter((t) => isOverdue(t)).length;

  totalCount.textContent   = total;
  pendingCount.textContent = pending;
  doneCount.textContent    = done;
  overdueCount.textContent = overdue;
}

// ===== Filtering & Sorting =====

/**
 * Get filtered and sorted tasks based on current filter/sort selections.
 * @returns {Object[]} Filtered and sorted array of task objects
 */
function getFilteredTasks() {
  let list = [...getTasks()];

  // Text search
  const q = searchInput.value.trim().toLowerCase();
  if (q) {
    list = list.filter((t) =>
      t.title.toLowerCase().includes(q) ||
      (t.category && t.category.toLowerCase().includes(q))
    );
  }

  // Status filter
  const status = filterStatus.value;
  if (status === "pending")   list = list.filter((t) => !t.done);
  if (status === "completed") list = list.filter((t) => t.done);

  // Priority filter
  const pri = filterPriority.value;
  if (pri !== "all") list = list.filter((t) => t.priority === pri);

  // Category filter
  const cat = filterCategory.value;
  if (cat !== "all") list = list.filter((t) => t.category === cat);

  // Sort
  const sort = sortBy.value;
  list.sort((a, b) => {
    switch (sort) {
      case "created-desc": return b.created - a.created;
      case "created-asc":  return a.created - b.created;
      case "due-asc":
        if (!a.due && !b.due) return 0;
        if (!a.due) return 1;
        if (!b.due) return -1;
        return a.due.localeCompare(b.due);
      case "due-desc":
        if (!a.due && !b.due) return 0;
        if (!a.due) return 1;
        if (!b.due) return -1;
        return b.due.localeCompare(a.due);
      case "priority-desc": return (PRIORITY_WEIGHT[b.priority] || 0) - (PRIORITY_WEIGHT[a.priority] || 0);
      case "priority-asc":  return (PRIORITY_WEIGHT[a.priority] || 0) - (PRIORITY_WEIGHT[b.priority] || 0);
      default: return 0;
    }
  });

  return list;
}

// ===== Task Rendering =====

/**
 * Render all task cards in the task list grid.
 * Shows empty state when no tasks match filters.
 */
function renderTasks() {
  const filtered = getFilteredTasks();
  const tasks = getTasks();
  taskList.innerHTML = "";

  if (filtered.length === 0) {
    emptyState.style.display = "block";
    emptyText.textContent = tasks.length === 0
      ? "No tasks yet. Add one above!"
      : "No tasks match your filters.";
  } else {
    emptyState.style.display = "none";
  }

  filtered.forEach((task) => {
    const card = document.createElement("div");
    card.className = "task-card" + (task.done ? " completed" : "");

    // Build meta badges
    const badges = [];
    badges.push(`<span class="badge badge-priority bp-${task.priority}">${task.priority}</span>`);
    if (task.category) {
      badges.push(`<span class="badge badge-category">${escapeHtml(task.category)}</span>`);
    }
    if (!initialTaskIds.has(task.id)) {
      badges.push('<span class="badge badge-new">New</span>');
    }

    // Due date line
    let dueLine = '';
    if (task.due) {
      const ov = isOverdue(task);
      const timeStr = task.time ? ' ' + formatTime(task.time) : '';
      dueLine = `<div class="task-info-item${ov ? ' overdue' : ''}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>${ov ? 'Overdue: ' : ''}${formatDate(task.due)}${timeStr}</div>`;
    } else if (task.time) {
      dueLine = `<div class="task-info-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>${formatTime(task.time)}</div>`;
    }

    card.innerHTML = `
      <div class="priority-stripe p-${task.priority}"></div>
      <div class="task-body">
        <div class="task-header">
          <div class="task-check ${task.done ? 'checked' : ''}" data-id="${task.id}" role="checkbox" aria-checked="${task.done}" tabindex="0">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 13l4 4L19 7"/></svg>
          </div>
          <div class="task-title">${escapeHtml(task.title)}</div>
        </div>
        <div class="task-info">
          ${badges.join('')}
          ${dueLine}
          ${(task.subtasks && task.subtasks.length) ? `<span class="badge badge-subtasks">${task.subtasks.filter(s=>s.done).length}/${task.subtasks.length} subtasks</span>` : ''}
        </div>
        ${(task.subtasks && task.subtasks.length) ? `
        <div class="subtask-list">
          <div class="subtask-progress"><div class="subtask-progress-fill" style="width:${Math.round((task.subtasks.filter(s=>s.done).length / task.subtasks.length)*100)}%"></div></div>
          ${task.subtasks.map(st => `
            <div class="subtask-item">
              <div class="subtask-check ${st.done ? 'checked' : ''}" data-task-id="${task.id}" data-sub-id="${st.id}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 13l4 4L19 7"/></svg>
              </div>
              <span class="${st.done ? 'subtask-done' : ''}">${escapeHtml(st.title)}</span>
            </div>
          `).join('')}
        </div>` : ''}
      </div>
      <div class="task-footer">
        <div class="task-info">${dueLine ? '' : '<span></span>'}</div>
        <div class="task-actions">
          <button class="btn-edit" data-id="${task.id}" title="Edit">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
          <button class="btn-del" data-id="${task.id}" title="Delete">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
          </button>
        </div>
      </div>
    `;
    taskList.appendChild(card);
  });

  updateStats();
  updateCategoryUI();
}

// ===== Add / Edit Form =====

/**
 * Reset the add/edit form to its default "Add New Task" state.
 */
function resetForm() {
  editingId = null;
  titleInput.value = "";
  dueInput.value = "";
  timeInput.value = "";
  priorityInput.value = "medium";
  categoryInput.value = "";
  formTitle.textContent = "Add New Task";
  saveBtn.textContent = "Add Task";
  cancelBtn.style.display = "none";
}

/**
 * Handle save button click — creates a new task or updates an existing one.
 */
saveBtn.addEventListener("click", () => {
  const title = titleInput.value.trim();
  if (!title) {
    titleInput.focus();
    titleInput.style.borderColor = "var(--danger)";
    setTimeout(() => titleInput.style.borderColor = "", 1500);
    return;
  }

  const list = getActiveList();
  if (!list) return;

  if (editingId) {
    const task = list.tasks.find((t) => t.id === editingId);
    if (task) {
      task.title    = title;
      task.due      = dueInput.value || null;
      task.time     = timeInput.value || null;
      task.priority = priorityInput.value;
      task.category = categoryInput.value.trim() || null;
      clearNotifiedFor(task.id);
    }
  } else {
    list.tasks.push({
      id:       generateId(),
      title:    title,
      due:      dueInput.value || null,
      time:     timeInput.value || null,
      priority: priorityInput.value,
      category: categoryInput.value.trim() || null,
      done:     false,
      created:  Date.now(),
    });
  }

  save();
  resetForm();
  renderAll();
});

cancelBtn.addEventListener("click", () => { resetForm(); });

titleInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveBtn.click();
});

// ===== Toggle Done / Edit / Delete =====

/**
 * Handle clicks on task cards — toggle done, edit, delete, subtask check.
 */
taskList.addEventListener("click", (e) => {
  const list = getActiveList();
  if (!list) return;

  // Subtask checkbox
  const subCheck = e.target.closest(".subtask-check");
  if (subCheck) {
    const task = list.tasks.find((t) => t.id === subCheck.dataset.taskId);
    if (task && task.subtasks) {
      const sub = task.subtasks.find((s) => s.id === subCheck.dataset.subId);
      if (sub) { sub.done = !sub.done; save(); renderAll(); }
    }
    return;
  }

  // Task checkbox
  const check = e.target.closest(".task-check");
  if (check) {
    const task = list.tasks.find((t) => t.id === check.dataset.id);
    if (task) {
      task.done = !task.done;
      task.completedAt = task.done ? Date.now() : null;
      save(); renderAll();
    }
    return;
  }

  // Edit button
  const editBtn = e.target.closest(".btn-edit");
  if (editBtn) {
    const task = list.tasks.find((t) => t.id === editBtn.dataset.id);
    if (task) {
      editingId = task.id;
      titleInput.value    = task.title;
      dueInput.value      = task.due || "";
      timeInput.value     = task.time || "";
      priorityInput.value = task.priority;
      categoryInput.value = task.category || "";
      formTitle.textContent = "Edit Task";
      saveBtn.textContent   = "Update Task";
      cancelBtn.style.display = "inline-flex";
      titleInput.focus();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
    return;
  }

  // Delete button
  const delBtn = e.target.closest(".btn-del");
  if (delBtn) {
    deletingId = delBtn.dataset.id;
    deleteModal.classList.add("active");
    return;
  }
});

/** Keyboard accessibility for task checkboxes */
taskList.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === " ") {
    const check = e.target.closest(".task-check");
    if (check) { e.preventDefault(); check.click(); }
  }
});

// ===== Delete Task Modal =====

confirmDelete.addEventListener("click", () => {
  if (deletingId) {
    const list = getActiveList();
    if (list) {
      list.tasks = list.tasks.filter((t) => t.id !== deletingId);
      save();
      renderAll();
    }
    deletingId = null;
  }
  deleteModal.classList.remove("active");
});

cancelDelete.addEventListener("click", () => {
  deletingId = null;
  deleteModal.classList.remove("active");
});

deleteModal.addEventListener("click", (e) => {
  if (e.target === deleteModal) { deletingId = null; deleteModal.classList.remove("active"); }
});

// ===== Filters =====

searchInput.addEventListener("input", renderTasks);
filterStatus.addEventListener("change", renderTasks);
filterPriority.addEventListener("change", renderTasks);
filterCategory.addEventListener("change", renderTasks);
sortBy.addEventListener("change", renderTasks);

// ===== Brain Dump (Tasks View) =====

/** Toggle brain dump section open/closed */
dumpToggle.addEventListener("click", () => {
  const isOpen = dumpBody.style.display !== "none";
  dumpBody.style.display = isOpen ? "none" : "block";
  dumpToggle.classList.toggle("open", !isOpen);
});

/**
 * Auto-correct text in the brain dump textarea via the server API.
 */
autocorrectBtn.addEventListener("click", async () => {
  const text = dumpText.value.trim();
  if (!text) { dumpText.focus(); return; }

  dumpStatus.textContent = "Correcting...";
  dumpStatus.className = "dump-status loading";
  autocorrectBtn.disabled = true;

  try {
    const resp = await fetch("/api/autocorrect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    if (!resp.ok) throw new Error("Server error");
    const data = await resp.json();
    dumpText.value = data.corrected;
    dumpStatus.textContent = "✓ Corrected!";
    dumpStatus.className = "dump-status";
  } catch (err) {
    dumpStatus.textContent = "Failed to auto-correct";
    dumpStatus.className = "dump-status error";
  }
  autocorrectBtn.disabled = false;
  setTimeout(() => { dumpStatus.textContent = ""; }, 3000);
});

/**
 * Parse brain dump text into individual task titles.
 * Splits by newlines, bullets, numbers, semicolons, commas, and "and".
 * @param {string} text - Raw brain dump text
 * @returns {string[]} Array of parsed task titles
 */
function parseDumpText(text) {
  let items = text
    .split(/[\n\r]+/)
    .flatMap((line) => line.split(/[;]/))
    .flatMap((line) => {
      const numbered = line.split(/(?:^|\s)(?:\d+[\.\)]\s)/);
      if (numbered.length > 1) return numbered;
      return [line];
    })
    .flatMap((line) => {
      return line.split(/(?:^|\s)[\-\*•]\s/);
    })
    .flatMap((line) => {
      const parts = line.split(/,\s*(?:and\s+)?|(?:^|\s)and\s+|(?:^|\s)&\s+/i);
      if (parts.length > 1) return parts;
      return [line];
    })
    .map((s) => s.replace(/^[\s\-\*•\d\.\)]+/, "").trim())
    .map((s) => s.replace(/[\.!]+$/, "").trim())
    .filter((s) => s.length >= 3 && s.length <= 200);

  // Capitalize first letter
  items = items.map((s) => s.charAt(0).toUpperCase() + s.slice(1));

  // Deduplicate
  const seen = new Set();
  return items.filter((s) => {
    const key = s.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/**
 * Extract tasks from brain dump text and show preview with indent/outdent controls.
 */
parseDumpBtn.addEventListener("click", () => {
  const text = dumpText.value.trim();
  if (!text) {
    dumpText.focus();
    return;
  }

  const tasks = parseDumpText(text);
  if (tasks.length === 0) {
    dumpPreview.style.display = "none";
    return;
  }

  dumpList.innerHTML = "";
  tasks.forEach((task, i) => {
    const item = document.createElement("div");
    item.className = "dump-item";
    item.dataset.level = "0";
    item.innerHTML = `
      <button class="dump-indent-btn" data-action="indent" title="Make subtask">→</button>
      <button class="dump-indent-btn" data-action="outdent" title="Make parent">←</button>
      <label class="dump-item-label">
        <input type="checkbox" checked data-index="${i}">
        <span>${escapeHtml(task)}</span>
      </label>
    `;
    dumpList.appendChild(item);
  });

  dumpSelectAll.checked = true;
  dumpPreview.style.display = "block";
});

/** Handle indent/outdent buttons in dump preview */
dumpList.addEventListener("click", (e) => {
  const btn = e.target.closest(".dump-indent-btn");
  if (!btn) return;
  e.preventDefault();
  const item = btn.closest(".dump-item");
  let level = parseInt(item.dataset.level) || 0;
  if (btn.dataset.action === "indent" && level === 0) {
    const prev = item.previousElementSibling;
    if (prev && parseInt(prev.dataset.level) === 0) {
      level = 1;
    }
  } else if (btn.dataset.action === "outdent" && level > 0) {
    level = 0;
  }
  item.dataset.level = level;
  item.style.paddingLeft = level ? "32px" : "";
});

/** Select/deselect all dump items */
dumpSelectAll.addEventListener("change", () => {
  const checkboxes = dumpList.querySelectorAll('input[type="checkbox"]');
  checkboxes.forEach((cb) => cb.checked = dumpSelectAll.checked);
});

/**
 * Add selected dump items as tasks (with parent-subtask structure).
 */
addDumpTasksBtn.addEventListener("click", () => {
  const list = getActiveList();
  if (!list) return;

  const items = dumpList.querySelectorAll(".dump-item");
  if (items.length === 0) return;

  let lastParentTask = null;

  items.forEach((item) => {
    const cb = item.querySelector('input[type="checkbox"]');
    if (!cb.checked) return;
    const span = item.querySelector("span");
    if (!span) return;
    const level = parseInt(item.dataset.level) || 0;
    const title = span.textContent;

    if (level === 0) {
      const task = {
        id:       generateId(),
        title:    title,
        due:      null,
        priority: "medium",
        category: null,
        done:     false,
        created:  Date.now(),
        subtasks: [],
      };
      list.tasks.push(task);
      lastParentTask = task;
    } else if (lastParentTask) {
      lastParentTask.subtasks.push({
        id:   generateId(),
        title: title,
        done:  false,
      });
    }
  });

  save();
  renderAll();

  // Reset dump
  dumpText.value = "";
  dumpPreview.style.display = "none";
  dumpList.innerHTML = "";
});
