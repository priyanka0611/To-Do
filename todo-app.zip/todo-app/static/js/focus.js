/* =============================================================
   FOCUS.JS — Focus Mode (25-Minute Pomodoro Timer):
   Task Selection, Timer Ring, Pause/Resume, Complete/Cancel
   ============================================================= */

/** Focus session duration in seconds (25 minutes) */
const FOCUS_DURATION = 25 * 60;

/**
 * Populate the focus task select dropdown.
 * Groups tasks into "Top Priorities" and "All Tasks".
 */
function populateFocusSelect() {
  const sel = document.getElementById("focusTaskSelect");
  if (!sel) return;
  const prevVal = sel.value;
  sel.innerHTML = '<option value="">Pick a task to focus on...</option>';

  // Add top 3 first
  const top3 = getTop3Tasks();
  const top3Ids = new Set(top3.map(t => t.task.id));

  if (top3.length > 0) {
    const grp1 = document.createElement("optgroup");
    grp1.label = "⭐ Top Priorities";
    top3.forEach(({ task }) => {
      const opt = document.createElement("option");
      opt.value = task.id;
      opt.textContent = task.title;
      grp1.appendChild(opt);
    });
    sel.appendChild(grp1);
  }

  // Add remaining pending tasks
  const others = [];
  data.lists.forEach(l => l.tasks.forEach(t => {
    if (!t.done && !top3Ids.has(t.id)) others.push(t);
  }));
  if (others.length > 0) {
    const grp2 = document.createElement("optgroup");
    grp2.label = "All Tasks";
    others.forEach(t => {
      const opt = document.createElement("option");
      opt.value = t.id;
      opt.textContent = t.title;
      grp2.appendChild(opt);
    });
    sel.appendChild(grp2);
  }
  sel.value = prevVal;
}

/**
 * Find a task by ID across all lists.
 * @param {string} id - Task ID to search for
 * @returns {Object|null} The task object or null
 */
function findTaskById(id) {
  for (const list of data.lists) {
    const t = list.tasks.find(t => t.id === id);
    if (t) return t;
  }
  return null;
}

/**
 * Update the SVG ring progress indicator based on remaining time.
 */
function updateFocusRing() {
  const ring = document.getElementById("focusRingProgress");
  if (!ring) return;
  const circumference = 2 * Math.PI * 52; // r=52
  const pct = focusRemaining / FOCUS_DURATION;
  ring.style.strokeDashoffset = circumference * pct;
}

/**
 * Update the timer display with remaining minutes and seconds.
 */
function updateFocusTimer() {
  const el = document.getElementById("focusTimer");
  if (!el) return;
  const m = Math.floor(focusRemaining / 60);
  const s = focusRemaining % 60;
  el.textContent = `${m}:${String(s).padStart(2, "0")}`;
}

/**
 * Start a focus session. Shows the active timer state.
 * Counts down every second and auto-completes when time runs out.
 */
function startFocus() {
  const sel = document.getElementById("focusTaskSelect");
  focusTaskId = sel ? sel.value : null;
  const task = focusTaskId ? findTaskById(focusTaskId) : null;

  document.getElementById("focusIdle").style.display = "none";
  document.getElementById("focusDone").style.display = "none";
  document.getElementById("focusActive").style.display = "block";

  const nameEl = document.getElementById("focusTaskName");
  nameEl.textContent = task ? task.title : "Free focus session";
  nameEl.style.display = task ? "inline-block" : "none";

  focusRemaining = FOCUS_DURATION;
  focusPaused = false;
  document.getElementById("focusSection").classList.remove("paused");
  updatePauseBtn();
  updateFocusTimer();
  updateFocusRing();

  focusInterval = setInterval(() => {
    if (focusPaused) return;
    focusRemaining--;
    updateFocusTimer();
    updateFocusRing();
    if (focusRemaining <= 0) {
      clearInterval(focusInterval);
      focusInterval = null;
      completeFocus();
    }
  }, 1000);
}

/**
 * Complete the focus session. Shows the completed state with celebration.
 * Sends a browser notification.
 */
function completeFocus() {
  document.getElementById("focusActive").style.display = "none";
  document.getElementById("focusDone").style.display = "block";
  const task = focusTaskId ? findTaskById(focusTaskId) : null;
  document.getElementById("focusDoneSub").textContent = task
    ? `Great focus on "${task.title}"`
    : "25 minutes of deep work — well done!";
  document.getElementById("focusMarkDoneBtn").style.display = task ? "" : "none";

  sendNotification("🎉 Focus Session Complete!",
    task ? `Done focusing on: ${task.title}` : "25 minutes of deep work completed!",
    "focus-done");
}

/**
 * Reset focus mode to idle state. Clears interval and restores defaults.
 */
function resetFocus() {
  clearInterval(focusInterval);
  focusInterval = null;
  focusRemaining = FOCUS_DURATION;
  focusPaused = false;
  focusTaskId = null;
  document.getElementById("focusSection").classList.remove("paused");
  document.getElementById("focusActive").style.display = "none";
  document.getElementById("focusDone").style.display = "none";
  document.getElementById("focusIdle").style.display = "block";
  updateFocusTimer();
  updateFocusRing();
  populateFocusSelect();
}

/**
 * Update the pause/resume button icon based on current state.
 */
function updatePauseBtn() {
  const btn = document.getElementById("focusPauseBtn");
  if (!btn) return;
  if (focusPaused) {
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="20" height="20"><polygon points="5 3 19 12 5 21 5 3"/></svg>';
    btn.title = "Resume";
  } else {
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="20" height="20"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>';
    btn.title = "Pause";
  }
}

// ===== Focus Mode Event Listeners =====

/** Start focus session */
document.getElementById("focusStartBtn").addEventListener("click", startFocus);

/** Toggle pause/resume */
document.getElementById("focusPauseBtn").addEventListener("click", () => {
  focusPaused = !focusPaused;
  document.getElementById("focusSection").classList.toggle("paused", focusPaused);
  updatePauseBtn();
});

/** Cancel current session */
document.getElementById("focusCancelBtn").addEventListener("click", resetFocus);

/** Start another session after completion */
document.getElementById("focusAgainBtn").addEventListener("click", resetFocus);

/** Mark the focused task as done after session completion */
document.getElementById("focusMarkDoneBtn").addEventListener("click", () => {
  if (focusTaskId) {
    const task = findTaskById(focusTaskId);
    if (task) { task.done = true; task.completedAt = Date.now(); save(); renderAll(); }
  }
  resetFocus();
  renderTodayView();
});
