/* =============================================================
   NAVIGATION.JS — Mode Switching (Today/Tasks/Focus/Insights/Systems),
   Nav Sidebar (Open/Close), User Menu Dropdown, "Go to Tasks" Button
   ============================================================= */

/**
 * Switch the app to a different view mode.
 * Updates button states, shows/hides view containers, and triggers renders.
 * @param {string} mode - One of: "today", "tasks", "focus", "insights", "systems"
 */
function switchMode(mode) {
  currentMode = mode;

  // Update mode toggle buttons
  modeBtns.forEach((b) => b.classList.toggle("active", b.dataset.mode === mode));

  // Update nav sidebar items
  document.querySelectorAll(".nav-item").forEach((n) => n.classList.toggle("active", n.dataset.mode === mode));

  // Show/hide view containers
  todayView.style.display       = mode === "today"    ? "block" : "none";
  tasksViewEls.tabs.style.display   = mode === "tasks" ? ""      : "none";
  tasksViewEls.layout.style.display = mode === "tasks" ? ""      : "none";
  focusViewEl.style.display     = mode === "focus"    ? "block" : "none";
  insightsView.style.display    = mode === "insights" ? "block" : "none";
  systemsView.style.display     = mode === "systems"  ? "block" : "none";

  // Trigger view-specific renders
  if (mode === "today")    renderTodayView();
  if (mode === "focus")    populateFocusSelect();
  if (mode === "insights") renderInsights();
  if (mode === "systems")  renderSystems();
}

// ===== Mode Toggle Buttons (Today / Tasks) =====
modeBtns.forEach((btn) => {
  btn.addEventListener("click", () => switchMode(btn.dataset.mode));
});

// ===== Nav Sidebar =====

const navMenuBtn  = document.getElementById("navMenuBtn");
const navSidebar  = document.getElementById("navSidebar");
const navOverlay  = document.getElementById("navOverlay");
const navCloseBtn = document.getElementById("navCloseBtn");
const navItems    = document.querySelectorAll(".nav-item");

/**
 * Open the navigation sidebar with overlay.
 */
function openNav() {
  navSidebar.classList.add("open");
  navOverlay.classList.add("open");
}

/**
 * Close the navigation sidebar.
 */
function closeNav() {
  navSidebar.classList.remove("open");
  navOverlay.classList.remove("open");
}

navMenuBtn.addEventListener("click", openNav);
navCloseBtn.addEventListener("click", closeNav);
navOverlay.addEventListener("click", closeNav);

/** Handle nav item clicks — switch mode and close sidebar */
navItems.forEach((item) => {
  item.addEventListener("click", () => {
    const mode = item.dataset.mode;
    modeBtns.forEach((b) => b.classList.remove("active"));
    navItems.forEach((n) => n.classList.remove("active"));
    item.classList.add("active");
    closeNav();
    switchMode(mode);
  });
});

// ===== "Go to Tasks" Button =====
document.getElementById("goToTasksBtn").addEventListener("click", () => switchMode("tasks"));

// ===== User Menu Dropdown =====
const userMenuEl   = document.getElementById("userMenu");
const userAvatarEl = document.getElementById("userAvatar");
if (userMenuEl && userAvatarEl) {
  userAvatarEl.addEventListener("click", (e) => {
    e.stopPropagation();
    userMenuEl.classList.toggle("open");
  });
  document.addEventListener("click", () => userMenuEl.classList.remove("open"));
}
