// ===== Firebase Configuration =====
// Replace the values below with your Firebase project config.
// Get these from: Firebase Console → Project Settings → Your Apps → Web App

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Skip Firebase if not configured (local-only mode)
const firebaseConfigured = firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("YOUR_");

if (firebaseConfigured) {
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  var db = firebase.firestore();
  var auth = firebase.auth();
} else {
  console.log("Firebase not configured — running in local-only mode");
  // Hide auth screen immediately, show app
  const _authScreen = document.getElementById("authScreen");
  if (_authScreen) _authScreen.style.display = "none";
  document.body.classList.add("authenticated");
}

// Google Sign-In
let firebaseUid = null;

if (firebaseConfigured) {
  const googleProvider = new firebase.auth.GoogleAuthProvider();

  window.signInWithGoogle = function () {
    auth.signInWithPopup(googleProvider).catch((err) => {
      console.error("Google sign-in failed:", err.message);
      if (err.code === "auth/popup-blocked" || err.code === "auth/popup-closed-by-user") {
        auth.signInWithRedirect(googleProvider);
      }
    });
  };

  window.signOutUser = function () {
    auth.signOut();
  };

  auth.onAuthStateChanged((user) => {
    const authScreen = document.getElementById("authScreen");
    const userMenu = document.getElementById("userMenu");

    if (user) {
      firebaseUid = user.uid;
      console.log("Signed in as:", user.displayName, "uid:", firebaseUid);

      if (authScreen) authScreen.style.display = "none";
      document.body.classList.add("authenticated");

      if (userMenu) {
        userMenu.style.display = "";
        const avatar = document.getElementById("userAvatar");
        const nameEl = document.getElementById("userName");
        const emailEl = document.getElementById("userEmail");
        if (avatar) avatar.src = user.photoURL || "";
        if (nameEl) nameEl.textContent = user.displayName || "User";
        if (emailEl) emailEl.textContent = user.email || "";
      }

      if (typeof syncFromCloud === "function") syncFromCloud();
    } else {
      firebaseUid = null;
      if (authScreen) authScreen.style.display = "flex";
      document.body.classList.remove("authenticated");
      if (userMenu) userMenu.style.display = "none";
    }
  });

  document.addEventListener("DOMContentLoaded", () => {
    const signInBtn = document.getElementById("googleSignInBtn");
    const signOutBtn = document.getElementById("signOutBtn");
    if (signInBtn) signInBtn.addEventListener("click", signInWithGoogle);
    if (signOutBtn) signOutBtn.addEventListener("click", signOutUser);
  });
}
