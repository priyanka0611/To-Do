/* =============================================================
   THEME.JS — Dark/Light Theme Initialization and Toggle
   ============================================================= */

/**
 * Initialize the theme from localStorage or default to light.
 * Sets the data-theme attribute on the HTML element.
 */
function initTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  document.documentElement.setAttribute("data-theme", saved || "light");
}

/**
 * Toggle between light and dark theme on button click.
 * Persists choice to localStorage.
 */
themeToggle.addEventListener("click", () => {
  const current = document.documentElement.getAttribute("data-theme");
  const next = current === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", next);
  localStorage.setItem(THEME_KEY, next);
});
