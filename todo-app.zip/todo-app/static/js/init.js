/* =============================================================
   INIT.JS — Application Initialization: Load Data, Render Views,
   Start Notification Checks, Set Initial View
   ============================================================= */

/**
 * Render all dynamic UI components.
 * Called after any data change to keep the UI in sync.
 */
function renderAll() {
  renderTabs();
  renderTasks();
  if (currentMode === "today") renderTodayView();
}

// ===== Bootstrap the Application =====

// Initialize theme from localStorage
initTheme();

// Load data from localStorage
load();
loadSystems();

// Render everything
renderAll();

// Start on Today view — hide tasks panels
tasksViewEls.tabs.style.display = "none";
tasksViewEls.layout.style.display = "none";
renderTodayView();

// Start notification system
requestNotifPermission();
updateNotifDot();
setInterval(checkReminders, 30000); // Check every 30 seconds
checkReminders(); // Initial check on load
