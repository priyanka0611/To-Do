/* =============================================================
   SYSTEMS.JS — Systems/Habits Engine: Streaks, Weekly Rates,
   Consistency, Identity Statements, Heatmap, Check-ins
   ============================================================= */

/**
 * Get the Monday start of the current week.
 * @param {Date} date - Reference date
 * @returns {Date} Monday of that week
 */
function getWeekStart(date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(d.setDate(diff));
}

/**
 * Get all 7 dates (Mon–Sun) of the current week as YYYY-MM-DD strings.
 * @returns {string[]} Array of 7 date strings
 */
function getWeekDates() {
  const start = getWeekStart(new Date());
  const dates = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    dates.push(d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0"));
  }
  return dates;
}

/**
 * Calculate the current streak (consecutive days checked in).
 * Allows today or yesterday as the starting point.
 * @param {string[]} checkins - Array of date strings
 * @returns {number} Current streak count in days
 */
function getStreakCount(checkins) {
  if (!checkins.length) return 0;
  const sorted = [...new Set(checkins)].sort().reverse();
  const today = todayStr();
  let streak = 0;
  let expected = new Date(today + "T00:00:00");

  if (sorted[0] !== today) {
    const yesterday = new Date(expected);
    yesterday.setDate(yesterday.getDate() - 1);
    const yStr = yesterday.getFullYear() + "-" + String(yesterday.getMonth()+1).padStart(2,"0") + "-" + String(yesterday.getDate()).padStart(2,"0");
    if (sorted[0] !== yStr) return 0;
    expected = yesterday;
  }

  for (const dateStr of sorted) {
    const expStr = expected.getFullYear() + "-" + String(expected.getMonth()+1).padStart(2,"0") + "-" + String(expected.getDate()).padStart(2,"0");
    if (dateStr === expStr) {
      streak++;
      expected.setDate(expected.getDate() - 1);
    } else if (dateStr < expStr) {
      break;
    }
  }
  return streak;
}

/**
 * Get this week's check-in count vs target frequency.
 * @param {Object} sys - System object with checkins and freq
 * @returns {{count: number, target: number}} Weekly check-in rate
 */
function getWeeklyRate(sys) {
  const weekDates = getWeekDates();
  const count = weekDates.filter((d) => sys.checkins.includes(d)).length;
  return { count, target: sys.freq };
}

/**
 * Calculate overall consistency percentage since system creation.
 * @param {Object} sys - System object with created, freq, and checkins
 * @returns {number} Consistency percentage (0-100)
 */
function getConsistencyPct(sys) {
  if (!sys.created) return 0;
  const start = new Date(sys.created);
  const now = new Date();
  const weeks = Math.max(1, Math.ceil((now - start) / (7 * 86400000)));
  const totalExpected = weeks * sys.freq;
  return Math.min(100, Math.round((sys.checkins.length / totalExpected) * 100));
}

/**
 * Build an identity statement for a system (habit identity reinforcement).
 * @param {Object} sys - System object with name and freq
 * @returns {string} Identity statement like '"You are a person who..."'
 */
function buildIdentity(sys) {
  const freqLabel = sys.freq === 7 ? "every day" : `${sys.freq}x/week`;
  return `"You are a person who ${sys.name.toLowerCase()} ${freqLabel}"`;
}

/**
 * Build an HTML heatmap showing the last 12 weeks of check-ins.
 * Uses intensity levels (l1, l2, l3) based on nearby check-in density.
 * @param {Object} sys - System object with checkins array
 * @returns {string} HTML string of heatmap cells
 */
function buildHeatmap(sys) {
  const cells = [];
  const today = new Date();
  const checkinSet = new Set(sys.checkins);
  for (let i = 83; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const ds = d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
    const checked = checkinSet.has(ds);
    let nearby = 0;
    for (let j = -1; j <= 1; j++) {
      const nd = new Date(d);
      nd.setDate(d.getDate() + j);
      const ns = nd.getFullYear() + "-" + String(nd.getMonth()+1).padStart(2,"0") + "-" + String(nd.getDate()).padStart(2,"0");
      if (checkinSet.has(ns)) nearby++;
    }
    let level = "";
    if (checked) level = nearby >= 3 ? "l3" : nearby >= 2 ? "l2" : "l1";
    const dayNames = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
    const title = dayNames[d.getDay()] + " " + d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    cells.push(`<div class="heatmap-cell ${level}" title="${title}${checked ? ' ✓' : ''}"></div>`);
  }
  return cells.join("");
}

/**
 * Render all system cards with stats, check-in buttons, week dots, and heatmaps.
 */
function renderSystems() {
  sysList.innerHTML = "";
  if (systems.length === 0) {
    sysEmptyState.style.display = "block";
    return;
  }
  sysEmptyState.style.display = "none";

  const today = todayStr();
  const weekDates = getWeekDates();

  systems.forEach((sys) => {
    const streak = getStreakCount(sys.checkins);
    const weekly = getWeeklyRate(sys);
    const consistency = getConsistencyPct(sys);
    const checkedToday = sys.checkins.includes(today);
    const identity = buildIdentity(sys);

    const card = document.createElement("div");
    card.className = "sys-card";

    const weekDotsHtml = weekDates.map((d) => {
      const filled = sys.checkins.includes(d);
      const isToday = d === today;
      return `<div class="sys-week-dot${filled ? ' filled' : ''}${isToday ? ' today' : ''}" title="${d}"></div>`;
    }).join("");

    card.innerHTML = `
      <div class="sys-card-top">
        <div class="sys-card-info">
          <div class="sys-card-name">${escapeHtml(sys.name)}</div>
          ${sys.time ? `<div class="sys-card-time"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg> ${formatTime(sys.time)}</div>` : ''}
          <div class="sys-identity">${identity}</div>
          <div class="sys-stats-row">
            <div class="sys-stat">
              <span class="sys-stat-val streak">${streak} day${streak !== 1 ? 's' : ''}</span>
              <span class="sys-stat-label">Current Streak</span>
            </div>
            <div class="sys-stat">
              <span class="sys-stat-val rate">${weekly.count}/${weekly.target}</span>
              <span class="sys-stat-label">This Week</span>
            </div>
            <div class="sys-stat">
              <span class="sys-stat-val">${consistency}%</span>
              <span class="sys-stat-label">Consistency</span>
            </div>
          </div>
        </div>
        <div class="sys-card-actions">
          <button class="sys-del" data-sys-id="${sys.id}" title="Delete system">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
          </button>
        </div>
      </div>
      <div class="sys-checkin-area">
        <button class="sys-checkin-btn${checkedToday ? ' checked-in' : ''}" data-sys-id="${sys.id}">
          ${checkedToday ? '✓ Done today' : '✓ Check in'}
        </button>
        ${checkedToday ? '<span class="sys-checkin-msg">Nice work! Keep it going.</span>' : ''}
        <div class="sys-week-dots">${weekDotsHtml}</div>
      </div>
      <div class="sys-heatmap-area">
        <div class="sys-heatmap-label">Last 12 weeks</div>
        <div class="heatmap">${buildHeatmap(sys)}</div>
      </div>
    `;
    sysList.appendChild(card);
  });
}

// ===== Add System =====
addSystemBtn.addEventListener("click", () => {
  const name = sysNameInput.value.trim();
  if (!name) {
    sysNameInput.focus();
    sysNameInput.style.borderColor = "var(--danger)";
    setTimeout(() => sysNameInput.style.borderColor = "", 1500);
    return;
  }
  systems.push({
    id: generateId(),
    name: name,
    time: sysTimeInput.value || null,
    freq: parseInt(sysFreqInput.value),
    checkins: [],
    created: todayStr(),
  });
  sysNameInput.value = "";
  sysTimeInput.value = "";
  saveSystems();
  renderSystems();
});

sysNameInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") addSystemBtn.click();
});

// ===== Check-in & Delete Handlers =====
sysList.addEventListener("click", (e) => {
  // Check-in button
  const checkinBtn = e.target.closest(".sys-checkin-btn");
  if (checkinBtn && !checkinBtn.classList.contains("checked-in")) {
    const sys = systems.find((s) => s.id === checkinBtn.dataset.sysId);
    if (sys) {
      const today = todayStr();
      if (!sys.checkins.includes(today)) {
        sys.checkins.push(today);
        saveSystems();
        renderSystems();
      }
    }
    return;
  }

  // Delete button
  const delBtn = e.target.closest(".sys-del");
  if (delBtn) {
    deletingSystemId = delBtn.dataset.sysId;
    deleteSystemModal.classList.add("active");
    return;
  }
});

// ===== Delete System Modal =====
confirmDeleteSystem.addEventListener("click", () => {
  if (deletingSystemId) {
    systems = systems.filter((s) => s.id !== deletingSystemId);
    deletingSystemId = null;
    saveSystems();
    renderSystems();
  }
  deleteSystemModal.classList.remove("active");
});
cancelDeleteSystem.addEventListener("click", () => {
  deletingSystemId = null;
  deleteSystemModal.classList.remove("active");
});
deleteSystemModal.addEventListener("click", (e) => {
  if (e.target === deleteSystemModal) { deletingSystemId = null; deleteSystemModal.classList.remove("active"); }
});
