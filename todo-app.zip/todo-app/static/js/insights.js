/* =============================================================
   INSIGHTS.JS — Weekly Insights: Completion Rate, Productive
   Time, Priority Behavior, Consistency, Category Focus
   ============================================================= */

/**
 * Render the Weekly Insights view with smart analytics cards.
 * Analyzes completed tasks to surface productivity patterns.
 */
function renderInsights() {
  const el = document.getElementById("insightsList");
  if (!el) return;

  const allTasks = [];
  data.lists.forEach((l) => allTasks.push(...l.tasks));

  if (allTasks.length === 0) {
    el.innerHTML = '<div class="insights-empty">Add some tasks to see your insights</div>';
    return;
  }

  const now = new Date();
  const weekAgo = new Date(now);
  weekAgo.setDate(weekAgo.getDate() - 7);
  const weekAgoMs = weekAgo.getTime();

  // Tasks created this week
  const thisWeek = allTasks.filter((t) => t.created >= weekAgoMs);
  const thisWeekDone = thisWeek.filter((t) => t.done);

  // All completed tasks with completedAt timestamp
  const completedWithTime = allTasks.filter((t) => t.done && t.completedAt);
  const completedThisWeek = completedWithTime.filter((t) => t.completedAt >= weekAgoMs);

  const insights = [];

  // ===== 1. Weekly Completion Rate =====
  if (thisWeek.length > 0) {
    const pct = Math.round((thisWeekDone.length / thisWeek.length) * 100);
    let emoji, comment;
    if (pct >= 80) { emoji = "🔥"; comment = "You're crushing it!"; }
    else if (pct >= 50) { emoji = "💪"; comment = "Solid progress this week"; }
    else if (pct >= 20) { emoji = "🌱"; comment = "Room to grow — keep going"; }
    else { emoji = "🐢"; comment = "Slow week — that's okay, refocus"; }
    const barColor = pct >= 70 ? "bar-green" : pct >= 40 ? "bar-orange" : "bar-red";
    insights.push({
      emoji,
      text: `You completed ${pct}% of this week's tasks`,
      detail: `${thisWeekDone.length} of ${thisWeek.length} tasks done. ${comment}`,
      bar: { pct, color: barColor },
    });
  }

  // ===== 2. Most Productive Time =====
  if (completedWithTime.length >= 3) {
    const hourCounts = {};
    completedWithTime.forEach((t) => {
      const h = new Date(t.completedAt).getHours();
      hourCounts[h] = (hourCounts[h] || 0) + 1;
    });
    const peakHour = Object.entries(hourCounts).sort((a, b) => b[1] - a[1])[0];
    if (peakHour) {
      const h = parseInt(peakHour[0]);
      const ampm = h >= 12 ? "PM" : "AM";
      const h12 = h % 12 || 12;
      const period = h < 12 ? "morning" : h < 17 ? "afternoon" : "evening";
      insights.push({
        emoji: "⏰",
        text: `Most productive around ${h12} ${ampm}`,
        detail: `You tend to complete tasks in the ${period}. Try scheduling important work then.`,
      });
    }
  }

  // ===== 3. Priority Behavior =====
  const highPri = allTasks.filter((t) => t.priority === "high");
  const highDone = highPri.filter((t) => t.done);
  const highPending = highPri.filter((t) => !t.done);
  if (highPri.length >= 2) {
    const highPct = Math.round((highDone.length / highPri.length) * 100);
    if (highPending.length > highDone.length) {
      const overdueHigh = highPending.filter((t) => isOverdue(t));
      insights.push({
        emoji: "⚠️",
        text: `${highPending.length} high-priority task${highPending.length > 1 ? "s" : ""} still pending`,
        detail: overdueHigh.length > 0
          ? `${overdueHigh.length} of them ${overdueHigh.length > 1 ? "are" : "is"} overdue. Consider tackling these first.`
          : "Try focusing on these before lower-priority items.",
      });
    } else if (highPct >= 70) {
      insights.push({
        emoji: "🎯",
        text: `${highPct}% of high-priority tasks completed`,
        detail: "Great job focusing on what matters most!",
        bar: { pct: highPct, color: "bar-green" },
      });
    }
  }

  // ===== 4. Streak / Consistency =====
  const last7Days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    last7Days.push(d.toISOString().slice(0, 10));
  }
  const activeDays = new Set();
  completedWithTime.forEach((t) => {
    const ds = new Date(t.completedAt).toISOString().slice(0, 10);
    if (last7Days.includes(ds)) activeDays.add(ds);
  });
  if (completedWithTime.length >= 3) {
    const dayCount = activeDays.size;
    if (dayCount >= 5) {
      insights.push({
        emoji: "📅",
        text: `Active ${dayCount} out of 7 days this week`,
        detail: "Impressive consistency! You're building a strong habit.",
        bar: { pct: Math.round((dayCount / 7) * 100), color: "bar-blue" },
      });
    } else if (dayCount >= 3) {
      insights.push({
        emoji: "📅",
        text: `Active ${dayCount} out of 7 days this week`,
        detail: "Good start — try to stay consistent daily.",
        bar: { pct: Math.round((dayCount / 7) * 100), color: "bar-orange" },
      });
    }
  }

  // ===== 5. Category Insight =====
  if (completedThisWeek.length >= 3) {
    const catCounts = {};
    completedThisWeek.forEach((t) => {
      const cat = t.category || "Uncategorized";
      catCounts[cat] = (catCounts[cat] || 0) + 1;
    });
    const topCat = Object.entries(catCounts).sort((a, b) => b[1] - a[1])[0];
    if (topCat && topCat[1] >= 2) {
      insights.push({
        emoji: "📂",
        text: `"${topCat[0]}" was your top focus area`,
        detail: `${topCat[1]} tasks completed in this category this week.`,
      });
    }
  }

  // Fallback when no insights could be generated
  if (insights.length === 0) {
    el.innerHTML = '<div class="insights-empty">Complete a few more tasks to unlock insights ✨</div>';
    return;
  }

  el.innerHTML = insights.map((ins) => `
    <div class="insight-card">
      <div class="insight-emoji">${ins.emoji}</div>
      <div class="insight-body">
        <div class="insight-text">${ins.text}</div>
        <div class="insight-detail">${ins.detail}</div>
        ${ins.bar ? `<div class="insight-bar-wrap"><div class="insight-bar ${ins.bar.color}" style="width:${ins.bar.pct}%"></div></div>` : ""}
      </div>
    </div>
  `).join("");
}
