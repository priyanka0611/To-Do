# My Todos

A full-featured productivity app built with **FastAPI + Jinja2 + Vanilla JS**. Includes task management, habit tracking, focus timer, and weekly insights — all with a premium, responsive UI.

---

## Features

- **Today View** — Landing page with greeting, motivational messages, and auto-prioritized Top 3 tasks
- **Task Management** — Multi-list tabs, add/edit/delete tasks, categories, priorities, due dates, subtasks
- **Brain Dump** — Type freely and auto-extract tasks with indent/outdent for subtask structure
- **Focus Mode** — 25-minute Pomodoro timer with pause/resume and task linking
- **Weekly Insights** — Smart analytics: completion rate, productive time, priority behavior, consistency
- **Systems (Habits)** — Habit tracker with streaks, weekly rates, consistency %, identity statements, and heatmaps
- **Notifications** — Browser reminders for tasks and systems with scheduled times
- **Dark Mode** — Full light/dark theme toggle
- **Cloud Sync** — Firebase Firestore + Google Auth (optional, runs local-only if unconfigured)
- **Auto-correct** — Server-side spelling correction for brain dump text

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | FastAPI + Uvicorn |
| Templates | Jinja2 |
| Frontend | Vanilla JS (no framework) |
| Storage | localStorage (primary), Firebase Firestore (optional) |
| Auth | Firebase Google Auth (optional) |
| Styling | Custom CSS with CSS variables |
| Font | Inter (Google Fonts) |

---

## Project Structure

```
todo-app/
├── main.py                  # FastAPI server (GET /, POST /api/autocorrect)
├── requirements.txt         # Python dependencies
├── templates/
│   └── index.html           # Main HTML template (all views)
├── static/
│   ├── css/
│   │   ├── base.css         # Reset, CSS variables (light/dark), body, auth screen, user menu
│   │   ├── layout.css       # Header, theme/notif toggles, container, two-column grid, tabs, stats, nav sidebar
│   │   ├── components.css   # Buttons, forms, filters, brain dump, badges, modals, empty state
│   │   ├── today.css        # Today hero, greeting, motivation, Top 3 priorities, today brain dump, footer
│   │   ├── tasks.css        # Task card grid, priority stripes, checkboxes, subtasks
│   │   ├── focus.css        # Focus mode view, timer ring, controls, paused/completed states
│   │   ├── insights.css     # Weekly insights hero, insight cards, progress bars
│   │   ├── systems.css      # Systems cards, stats, check-in, week dots, heatmap
│   │   └── responsive.css   # Media queries (900/768/600/380px) + touch device improvements
│   └── js/
│       ├── firebase-config.js  # Firebase configuration (placeholder, detects unconfigured state)
│       ├── state.js            # Constants, app state variables, all DOM element references
│       ├── helpers.js          # Utility functions: ID generation, HTML escaping, date/time formatting
│       ├── storage.js          # LocalStorage load/save, Firebase cloud sync (debounced)
│       ├── theme.js            # Dark/light theme initialization and toggle
│       ├── notifications.js    # Browser notifications: permission, bell status, reminder checks
│       ├── tabs.js             # List tab rendering, context menu, add/rename/delete list
│       ├── tasks.js            # Task CRUD, rendering, filtering, sorting, categories, stats, brain dump
│       ├── today.js            # Today view: greeting, motivation, Top 3 scoring, today brain dump
│       ├── insights.js         # Weekly insights: completion rate, productive time, priority, consistency
│       ├── focus.js            # Focus mode: 25-min Pomodoro timer, pause/resume, complete/cancel
│       ├── systems.js          # Habits engine: streaks, weekly rates, consistency, heatmap, check-ins
│       ├── navigation.js       # Mode switching, nav sidebar open/close, user menu dropdown
│       └── init.js             # App bootstrap: renderAll, load data, start notifications
```

---

## Setup

```bash
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Open [http://localhost:8000](http://localhost:8000) in your browser.

---

## Firebase (Optional)

To enable cloud sync and Google sign-in, update `static/js/firebase-config.js` with your Firebase project credentials. Without configuration, the app runs fully in local-only mode using localStorage.
